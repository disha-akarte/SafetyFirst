//
//  VehicleSchedule.h
//  Akarte_Disha_FinalProject
//
//  Created by Disha Akarte on 4/18/17.
//  Copyright © 2017 Disha Akarte. All rights reserved.
//

#ifndef VehicleSchedule_h
#define VehicleSchedule_h

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import "Vehicle.h"

@class Vehicle;

@interface VehicleSchedule : NSObject

@property (nonatomic) NSInteger scheduleId;
@property (strong, nonatomic) NSString *vehicleNumber;
@property (strong, nonatomic) NSString *departureDate;
@property (strong, nonatomic) NSString *departureTime;
@property (strong, nonatomic) NSString *seatsAvailable;
@property (strong, nonatomic) NSString *vehicleCapacity;
@property (strong, nonatomic) NSString *vehicleNumber;
@property (strong, nonatomic) NSMutableArray *listOfRiders;


@end


#endif /* VehicleSchedule_h */
