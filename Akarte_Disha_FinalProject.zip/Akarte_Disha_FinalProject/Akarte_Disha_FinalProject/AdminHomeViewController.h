//
//  AdminHomeViewController.h
//  Akarte_Disha_FinalProject
//
//  Created by Disha Akarte on 4/19/17.
//  Copyright © 2017 Disha Akarte. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AdminHomeViewController : UIViewController<UINavigationControllerDelegate, UITextFieldDelegate,UIPickerViewDataSource, UIPickerViewDelegate>

@property (weak, nonatomic) IBOutlet UIDatePicker *schedule_date;
- (IBAction)submitSchedule:(id)sender;
- (IBAction)backToHome:(id)sender;
@property (weak, nonatomic) IBOutlet UIPickerView *vehicleNumberPicker;
@property (strong, nonatomic) NSMutableArray *vehicleList;

@end
