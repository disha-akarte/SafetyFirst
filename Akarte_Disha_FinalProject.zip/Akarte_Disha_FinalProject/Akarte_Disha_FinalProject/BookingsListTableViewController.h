//
//  BookingsListTableViewController.h
//  Akarte_Disha_FinalProject
//
//  Created by Disha Akarte on 4/25/17.
//  Copyright © 2017 Disha Akarte. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Student.h"
#import "Schedule.h"
#import "Vehicle.h"


@interface BookingsListTableViewController : UITableViewController

@property (strong, nonatomic)  NSMutableArray<Schedule*> *listOfBookings;
@property (strong, nonatomic) Student* student;
- (IBAction)logout:(id)sender;
@property (strong, nonatomic) IBOutlet UITableView *bookingsTableView;
@property Schedule *passedSchedule;

@end
