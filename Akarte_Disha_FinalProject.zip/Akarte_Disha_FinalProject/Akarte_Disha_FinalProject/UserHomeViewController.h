//
//  UserHomeViewController.h
//  Akarte_Disha_FinalProject
//
//  Created by Disha Akarte on 4/14/17.
//  Copyright © 2017 Disha Akarte. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Login.h"

@interface UserHomeViewController : UITabBarController<UITabBarControllerDelegate>

@property (strong, nonatomic)  Login* login;

@end
