//
//  LoginViewController.h
//  Akarte_Disha_FinalProject
//
//  Created by Disha Akarte on 4/1/17.
//  Copyright © 2017 Disha Akarte. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Login.h"
#import "Vehicle.h"

@interface LoginViewController : UIViewController

@property (strong, nonatomic)  Login *login;
@property (strong, nonatomic)  Student *student;
@property (strong, nonatomic) Vehicle *vehicle;
- (IBAction)callNUPD:(id)sender;


@property (weak, nonatomic) IBOutlet UITextField *usernameField;
@property (weak, nonatomic) IBOutlet UITextField *passwordField;
@property (weak, nonatomic) IBOutlet UIButton *loginButton;

@property (strong, nonatomic) NSMutableArray *vehList;

- (IBAction)signin:(id)sender;
- (IBAction)reset:(id)sender;
- (IBAction)signup:(id)sender;

@property (weak, nonatomic) IBOutlet UIImageView *headerImage;

-(Login*)getLoginObject:(NSDictionary*)jsonData;

@end
