//
//  SignUpOptionViewController.h
//  Akarte_Disha_FinalProject
//
//  Created by Disha Akarte on 4/10/17.
//  Copyright © 2017 Disha Akarte. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SignUpOptionViewController : UIViewController
- (IBAction)StudentRegistration:(id)sender;
- (IBAction)VehicleRegistration:(id)sender;
- (IBAction)goBack:(id)sender;

@end
