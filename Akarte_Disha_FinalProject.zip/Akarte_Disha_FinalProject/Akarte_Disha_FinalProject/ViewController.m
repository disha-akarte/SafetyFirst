//
//  ViewController.m
//  Akarte_Disha_FinalProject
//
//  Created by Disha Akarte on 4/1/17.
//  Copyright © 2017 Disha Akarte. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
