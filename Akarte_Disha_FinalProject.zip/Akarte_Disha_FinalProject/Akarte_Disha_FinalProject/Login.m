//
//  Login.m
//  Akarte_Disha_FinalProject
//
//  Created by Disha Akarte on 4/1/17.
//  Copyright © 2017 Disha Akarte. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Login.h"

@implementation Login

@synthesize loginid,username,password,role,student,vehicle;

-(id)init
{
    self = [super init];
    if(self){
        student =[[Student alloc]init];
        vehicle =[[Vehicle alloc]init];

    }
    return self;
}

@end
