//
//  VehicleSchedulesViewController.m
//  Akarte_Disha_FinalProject
//
//  Created by Disha Akarte on 4/27/17.
//  Copyright © 2017 Disha Akarte. All rights reserved.
//

#import "VehicleSchedulesViewController.h"
#import "RiderDetailsViewController.h"

@interface VehicleSchedulesViewController ()

@end

@implementation VehicleSchedulesViewController
@synthesize student,schedule,listOfSchedules,schedulePicker,riderTableView,timePicker,listOfRiders;

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.listOfRiders = [[NSMutableArray alloc]init];
    
    self.timePicker.dataSource = self;
    self.timePicker.delegate = self;
    self.schedulePicker.dataSource = self;
    self.schedulePicker.delegate = self;

    [self.navigationItem.backBarButtonItem setEnabled:true];
    NSString* Url = @"http://localhost:8080/safetyfirst/getSchedule";
    NSURL *url = [NSURL URLWithString:Url];
    
    NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:url];
    [request setHTTPMethod:@"GET"];
    
    NSError *error = [[NSError alloc] init];
    
    NSHTTPURLResponse *response = nil;
    
    NSData *urlData=[NSURLConnection sendSynchronousRequest:request returningResponse:&response error:&error];
    
    NSLog(@"Response Code : %ld", (long)[response statusCode]);
    
    if ([response statusCode] >= 200 && [response statusCode] < 300)
    {
        NSError *error = nil;
        NSDictionary *jsonData = [NSJSONSerialization
                                  JSONObjectWithData:urlData
                                  options:NSJSONReadingMutableContainers
                                  error:&error];
        NSLog(@"Response is : %@", jsonData);
        
        
        self.listOfSchedules = [[NSMutableArray alloc]init];
        for(NSDictionary * dict in jsonData)
        {
            Schedule *sch = [[Schedule alloc]init];
            sch.scheduleId = [dict valueForKey:@"scheduleID"];
            sch.departureTime = [dict valueForKey:@"departureTime"];
            sch.departureDate = [dict valueForKey:@"departureDate"];
            
            Vehicle *v = [[Vehicle alloc]init];
            v.vehicleId = [[[dict valueForKey:@"vehicleID"]init] integerValue];
            v.vehicleCapacity = [dict valueForKey:@"capacity"];
            v.vehicleNumber = [dict valueForKey:@"vehicleNumber"];
            v.vehicleId = [[dict valueForKey:@"loginid"] integerValue];
            
            NSString *r = [dict valueForKey:@"riders"];
            
            for(NSDictionary * dict in r)
            {
                Student *stu = [[Student alloc]init];
                stu.studentId = [[dict valueForKey:@"studentid"] integerValue];
                stu.firstName = [dict valueForKey:@"firstname"];
                stu.lastName = [dict valueForKey:@"lastname"];
                stu.NUID = [dict valueForKey:@"nuid"];
                stu.phone = [dict valueForKey:@"phone"];
                [sch.riders addObject:stu];
            }
            
            NSLog(@"Riders in the cab are : %lu",(unsigned long)sch.riders.count);
            
            
            sch.vehicle = v;
            
            [self.listOfSchedules addObject:sch];
        }
        NSMutableArray<Schedule *> *finalSchedules = [[NSMutableArray alloc]init];
        for(Schedule *sch in listOfSchedules){
            if(sch.vehicle.vehicleNumber == self.vehicle.vehicleNumber){
                [finalSchedules addObject:sch];
            }
        }
        
        self.listOfSchedules = finalSchedules;
        
        self.dd = [[NSMutableArray alloc]init];
        self.dt = [[NSMutableArray alloc]init];
        
        for(Schedule * s in self.listOfSchedules)
        {
            [self.dd addObject:s.departureDate];
            [self.dt addObject:s.departureTime];
        }
        
        NSLog(@"Available departures : %@",self.dd);
        NSLog(@"Available times : %@",self.dt);
        
        NSSet *uniqueDD = [NSSet setWithArray:self.dd];
        self.dd = [[uniqueDD allObjects] mutableCopy];
        
        NSSet *uniqueDT = [NSSet setWithArray:self.dt];
        self.dt = [[uniqueDT allObjects] mutableCopy];
        
        /*
        for(Schedule *s in self.listOfSchedules){
            if(self.dt[0]==s.departureTime && self.dd[0] == s.departureDate){
                self.listOfRiders = s.riders;
            }
        }*/
        
    }
    else{
        [self alertStatus:@"Connection Failed" :@"Connection Failed!" :0];
    }

    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


// The number of columns of data
- (int)numberOfComponentsInPickerView:(UIPickerView *)pickerView
{
    return 1;
}


// The number of rows of data
- (int)pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component
{
    if (pickerView == self.schedulePicker) {
        return self.dd.count;
    } else {
        return [self.dt count];
    }
}

// The data to return for the row and component (column) that's being passed in
- (NSString*)pickerView:(UIPickerView *)pickerView titleForRow:(NSInteger)row forComponent:(NSInteger)component
{
    if (pickerView == self.schedulePicker) {
        return self.dd[row];
    } else {
        return self.dt[row];
    }
    
    
}

/*Table section*/
-(void) tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    UITableViewCell *cell=[tableView cellForRowAtIndexPath:indexPath];
    
    NSString *name = cell.textLabel.text;
    
    Boolean flag = false;
    
    for(Student *s in self.listOfRiders ){
        NSString *fullName = [[s.firstName stringByAppendingString:@" "]stringByAppendingString:s.lastName];
        NSComparisonResult result1 = [name compare:fullName];
        if(result1 == NSOrderedSame) {
            flag = true;
        }
    }
    
    if(flag == false){
        
        UIAlertController* alert = [UIAlertController alertControllerWithTitle:@"Error" message:@"No results found!" preferredStyle:UIAlertControllerStyleAlert];
        
        UIAlertAction* defaultAction = [UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:^(UIAlertAction * action) {}];
        [alert addAction:defaultAction];
        
        [self presentViewController:alert animated:YES completion:nil];
        
    }else
    {
        [self performSegueWithIdentifier:@"viewDetails" sender:self];
    }
    
}


- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return [self.listOfRiders count];
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *simpleTableIdentifier = @"cell";
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:simpleTableIdentifier];
    
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:simpleTableIdentifier];
    }
    

    Student *rh = [self.listOfRiders objectAtIndex:indexPath.row];
    cell.accessoryType=UITableViewCellAccessoryDisclosureIndicator;
    cell.textLabel.text = [NSString stringWithFormat:@"%@ %@", rh.firstName, rh.lastName];
    cell.detailTextLabel.text = [NSString stringWithFormat:@"%@", rh.NUID];
    
    return cell;
}

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
    if ([[segue identifier] isEqualToString:@"viewDetails"]){
        NSIndexPath *path=[riderTableView indexPathForSelectedRow];
        
        RiderDetailsViewController *viewdetails = segue.destinationViewController;
        viewdetails.listOfRiders = self.listOfRiders;
        viewdetails.index = path.row;
    }
}

- (IBAction)fetchList:(id)sender {
    NSInteger roleIndex = [self.schedulePicker selectedRowInComponent:0];
    NSString* selectedDate=self.dd[roleIndex];
    
    NSInteger timeRoleIndex = [self.timePicker selectedRowInComponent:0];
    NSString* selectedTime=self.dt[timeRoleIndex];

    for(Schedule *schedule in self.listOfSchedules){
        if(selectedDate == schedule.departureDate && selectedTime == schedule.departureTime){
            self.listOfRiders = schedule.riders;
        }
    }
    
    self.riderTableView.delegate = self;
    self.riderTableView.dataSource = self;
    
    [self.riderTableView reloadData]; //just call reloadData on the tableView
}

- (IBAction)logout:(id)sender {
    [self.presentingViewController.presentingViewController dismissViewControllerAnimated: true completion: nil];
}

- (IBAction)back:(id)sender {
    [self dismissViewControllerAnimated:YES completion:nil];
}

- (void) alertStatus:(NSString *)msg :(NSString *)title :(int) tag
{
    UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:title
                                                        message:msg
                                                       delegate:self
                                              cancelButtonTitle:@"Ok"
                                              otherButtonTitles:nil, nil];
    alertView.tag = tag;
    [alertView show];
}

@end
