//
//  UserProfileViewController.m
//  Akarte_Disha_FinalProject
//
//  Created by Disha Akarte on 4/14/17.
//  Copyright © 2017 Disha Akarte. All rights reserved.
//

#import "UserProfileViewController.h"

@interface UserProfileViewController ()

@end

@implementation UserProfileViewController
@synthesize firstnamefield,lastnamefield,nuidfield,phonefield,student,barCodeView, profilePhoto, fineField;

- (void)viewDidLoad {
    [super viewDidLoad];
    
    
    // Do any additional setup after loading the view.
    self.firstnamefield.text = self.student.firstName;
    self.lastnamefield.text = student.lastName;
    self.nuidfield.text = self.student.NUID;
    self.phonefield.text = self.student.phone;
    self.fineField.text = self.student.fine;

    
    NSString *qrString = self.student.NUID;
    NSData *stringData = [qrString dataUsingEncoding: NSUTF8StringEncoding];
    
    CIFilter *qrFilter = [CIFilter filterWithName:@"CIQRCodeGenerator"];
    [qrFilter setValue:stringData forKey:@"inputMessage"];
    [qrFilter setValue:@"H" forKey:@"inputCorrectionLevel"];
    
    CIImage *qrImage = qrFilter.outputImage;
    float scaleX = self.barCodeView.frame.size.width / qrImage.extent.size.width;
    float scaleY = self.barCodeView.frame.size.height / qrImage.extent.size.height;
    
    qrImage = [qrImage imageByApplyingTransform:CGAffineTransformMakeScale(scaleX, scaleY)];
    
    self.barCodeView.image = [UIImage imageWithCIImage:qrImage
                                                 scale:[UIScreen mainScreen].scale orientation:UIImageOrientationUp];
    
}

- (CIImage *)createQRForString:(NSString *)qrString {
    NSData *stringData = [qrString dataUsingEncoding: NSISOLatin1StringEncoding];
    
    CIFilter *qrFilter = [CIFilter filterWithName:@"CIQRCodeGenerator"];
    [qrFilter setValue:stringData forKey:@"inputMessage"];
    
    return qrFilter.outputImage;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

- (IBAction)logout:(id)sender {
        [self dismissViewControllerAnimated:YES completion:nil];
}

@end
