//
//  VehicleDetailsViewController.h
//  Akarte_Disha_FinalProject
//
//  Created by Disha Akarte on 4/27/17.
//  Copyright © 2017 Disha Akarte. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Login.h"

@interface VehicleDetailsViewController : UIViewController<UINavigationBarDelegate>

@property (strong, atomic) Login *login;
@property (strong, atomic) Vehicle *vehicle;
@property (weak, nonatomic) IBOutlet UITextField *vehiNumber;
@property (weak, nonatomic) IBOutlet UITextField *vehCapacity;
- (IBAction)logout:(id)sender;
@property (weak, nonatomic) IBOutlet UITextField *vehUsername;
- (IBAction)back:(id)sender;

@end
