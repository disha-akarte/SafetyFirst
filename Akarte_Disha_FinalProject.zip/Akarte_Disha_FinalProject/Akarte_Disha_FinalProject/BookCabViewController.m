//
//  BookCabViewController.m
//  Akarte_Disha_FinalProject
//
//  Created by Disha Akarte on 4/21/17.
//  Copyright © 2017 Disha Akarte. All rights reserved.
//

#import "BookCabViewController.h"
#import "UserHomeViewController.h"

@interface BookCabViewController ()

@end

@implementation BookCabViewController
@synthesize dt,dd,schedule,student,listOfSchedules,bookButton,blvc;

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.datePicker.dataSource = self;
    self.datePicker.delegate = self;
    self.timePicker.dataSource = self;
    self.timePicker.delegate = self;
    
    bookButton.enabled = false;
 

}

- (void)viewWillDisappear:(BOOL)animated:(BOOL)animated{
    
    blvc.passedSchedule = self.schedule;
}

- (void) viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    //your code
    NSString* Url = @"http://localhost:8080/safetyfirst/getSchedule";
    NSURL *url = [NSURL URLWithString:Url];
    
    NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:url];
    [request setHTTPMethod:@"GET"];
    
    NSError *error = [[NSError alloc] init];
    
    NSHTTPURLResponse *response = nil;
    
    NSData *urlData=[NSURLConnection sendSynchronousRequest:request returningResponse:&response error:&error];
    
    NSLog(@"Response Code : %ld", (long)[response statusCode]);
    
    if ([response statusCode] >= 200 && [response statusCode] < 300)
    {
        NSError *error = nil;
        NSDictionary *jsonData = [NSJSONSerialization
                                  JSONObjectWithData:urlData
                                  options:NSJSONReadingMutableContainers
                                  error:&error];
        NSLog(@"Response is : %@", jsonData);
        
        
        self.listOfSchedules = [[NSMutableArray alloc]init];
        for(NSDictionary * dict in jsonData)
        {
            Schedule *sch = [[Schedule alloc]init];
            sch.scheduleId = [dict valueForKey:@"scheduleID"];
            sch.departureTime = [dict valueForKey:@"departureTime"];
            sch.departureDate = [dict valueForKey:@"departureDate"];
            
            Vehicle *v = [[Vehicle alloc]init];
            v.vehicleId = [[[dict valueForKey:@"vehicleID"]init] integerValue];
            v.vehicleCapacity = [dict valueForKey:@"capacity"];
            v.vehicleNumber = [dict valueForKey:@"vehicleNumber"];
            v.vehicleId = [[dict valueForKey:@"loginid"] integerValue];
            
            NSString *r = [dict valueForKey:@"riders"];
            
            
            for(NSDictionary * dict in r)
            {
                Student *stu = [[Student alloc]init];
                stu.studentId = [[dict valueForKey:@"studentid"] integerValue];
                stu.firstName = [dict valueForKey:@"firstname"];
                stu.lastName = [dict valueForKey:@"lastname"];
                stu.NUID = [dict valueForKey:@"nuid"];
                stu.phone = [dict valueForKey:@"phone"];
                [sch.riders addObject:stu];
            }
            
            NSLog(@"Riders in the cab are : %lu",(unsigned long)sch.riders.count);
            
            
            sch.vehicle = v;
            
            [self.listOfSchedules addObject:sch];
        }
        
        self.dd = [[NSMutableArray alloc]init];
        self.dt = [[NSMutableArray alloc]init];
        
        for(NSDictionary * dict in jsonData)
        {
            [self.dd addObject:[dict valueForKey:@"departureDate"]];
            [self.dt addObject:[dict valueForKey:@"departureTime"]];
        }
        
        NSLog(@"Available departures : %@",self.dd);
        NSLog(@"Available times : %@",self.dt);
        
        NSSet *uniqueDD = [NSSet setWithArray:self.dd];
        self.dd = [[uniqueDD allObjects] mutableCopy];
        
        NSSet *uniqueDT = [NSSet setWithArray:self.dt];
        self.dt = [[uniqueDT allObjects] mutableCopy];

    }
    else{
        [self alertStatus:@"Connection Failed" :@"Connection Failed!" :0];
    }
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


// The number of columns of data
- (int)numberOfComponentsInPickerView:(UIPickerView *)pickerView
{
    return 1;
}


// The number of rows of data
- (int)pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component
{
    if (pickerView == self.datePicker) {
        return self.dd.count;
    } else {
        return [self.dt count];
    }
}

// The data to return for the row and component (column) that's being passed in
- (NSString*)pickerView:(UIPickerView *)pickerView titleForRow:(NSInteger)row forComponent:(NSInteger)component
{
    if (pickerView == self.datePicker) {
         return self.dd[row];
    } else {
        return self.dt[row];
    }

   
}

// Catpure the picker view selection
- (void)pickerView:(UIPickerView *)pickerView didSelectRow:(NSInteger)row inComponent:(NSInteger)component
{
    bookButton.enabled = false;
}

#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
    if([segue.identifier isEqualToString:@"cabBooked"]){
        
        
        UINavigationController *navigationController = (UINavigationController *)[segue destinationViewController];
        //navigationController.childViewControllers[0];
        
    }

}


- (void) alertStatus:(NSString *)msg :(NSString *)title :(int) tag
{
    UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:title
                                                        message:msg
                                                       delegate:self
                                              cancelButtonTitle:@"Ok"
                                              otherButtonTitles:nil, nil];
    alertView.tag = tag;
    [alertView show];
}


- (IBAction)checkAvailability:(id)sender {
    
    NSInteger roleIndex = [_datePicker selectedRowInComponent:0];
    NSString* selectedDate=self.dd[roleIndex];
    
    NSInteger timeRoleIndex = [_timePicker selectedRowInComponent:0];
    NSString* selectedTime=self.dt[timeRoleIndex];
    
    Boolean found = false;

    for (Schedule *s in listOfSchedules) {
        
        if([s.departureDate isEqualToString:selectedDate] && [s.departureTime isEqualToString:selectedTime]){
            
            NSInteger alreadyBooked = [s.riders count];
            NSInteger availableSeats = [s.vehicle.vehicleCapacity integerValue] - alreadyBooked;
            
            if(availableSeats>0){
                _seatsAvailable.text = [NSString stringWithFormat:@"%li", (long)availableSeats];
                bookButton.enabled = true;
                self.schedule = s;
                found = true;
                break;
            }
            else{
                [self alertStatus:@"This cab is fully booked. Try the next one" :@"Overbooked!" :0];
                found = true;
                break;
            }
        }

    }
    
    if(found == false){
            _seatsAvailable.text = @" ";
            [self alertStatus:@"Sorry Schedule not available" :@"Invalid schedule!" :0];
    }
    
}


- (IBAction)book:(id)sender {
    
    NSLog(@"Student is : %@", self.student);
    NSLog(@"Schedule is : %@ ", self.schedule);
    
    BOOL bookedFlag = false;
    
    for(Student *std in self.schedule.riders){
        if(std.NUID == self.student.NUID){
            bookedFlag = true;
        }
    }
    
    if(bookedFlag){
        [self alertStatus:@"You have already booked this shuttle" :@"Invalid booking!" :0];
    }
    else{
    
    
    NSString* Url = @"http://localhost:8080/safetyfirst/addRider";
    NSURL *url = [NSURL URLWithString:Url];
    
    NSDictionary *studentInfo = [NSDictionary dictionaryWithObjectsAndKeys:
                                 self.student.NUID,@"nuid",
                                 self.student.phone,@"phone",
                                 nil];
    
    NSLog(@"Student Info is : %@", studentInfo);
    
    
    NSDictionary *scheduleinfo = [NSDictionary dictionaryWithObjectsAndKeys:
                             self.schedule.scheduleId ,@"scheduleID",
                             nil];
    
    NSLog(@"Schedule Info is : %@", scheduleinfo);
    
    NSDictionary *infoToSend = [NSDictionary dictionaryWithObjectsAndKeys:
                                  scheduleinfo , @"schedule",
                                  studentInfo ,@"student",
                                  nil];
    
    NSLog(@"Request Info is : %@", infoToSend);
    
    NSData *postData = [NSJSONSerialization dataWithJSONObject:infoToSend options:NSJSONWritingPrettyPrinted error:nil];
    
    NSString *postLength = [NSString stringWithFormat:@"%lu", (unsigned long)[postData length]];
    
    NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:url cachePolicy:NSURLRequestReloadIgnoringLocalCacheData timeoutInterval:10];
    [request setHTTPMethod:@"POST"];
    [request setValue:postLength forHTTPHeaderField:@"Content-Length"];
    [request setValue:@"application/json" forHTTPHeaderField:@"Accept"];
    [request setValue:@"application/json" forHTTPHeaderField:@"Content-Type"];
    [request setHTTPBody:postData];
    
    NSLog(@"Request is : %@", request);

    
    NSError *error = [[NSError alloc] init];
    
    NSHTTPURLResponse *response = nil;
    
    NSData *urlData=[NSURLConnection sendSynchronousRequest:request returningResponse:&response error:&error];
    
    NSLog(@"Response Code : %ld", (long)[response statusCode]);
    
    if ([response statusCode] >= 200 && [response statusCode] < 300)
    {
        NSError *error = nil;
        NSDictionary *jsonData = [NSJSONSerialization
                                  JSONObjectWithData:urlData
                                  options:NSJSONReadingMutableContainers
                                  error:&error];
        NSLog(@"Response is : %@", jsonData);
        
        if(jsonData!=nil){
            
            [self.student.listOfBookings addObject:self.schedule];
            for (Schedule *s in listOfSchedules) {
                
                if(s == self.schedule){
                    NSInteger availableSeats = [s.vehicle.vehicleCapacity integerValue] - 1;
                    s.vehicle.vehicleCapacity = [NSString stringWithFormat:@"%ld",(long)availableSeats];
                }
                
            }

            
            [self alertStatus:@"Booking Successful" :@"Cab Booked!" :0];
          //  [self performSegueWithIdentifier:@"cabBooked" sender:self];
            
        }
        else{
            [self alertStatus:@"Booking failed" :@"Booking failed!" :0];
        }
    }
    else{
        [self alertStatus:@"Connection Failed" :@"Connection Failed!" :0];
    }
    }

}

- (IBAction)logout:(id)sender {
    [self dismissViewControllerAnimated:YES completion:nil];
}
@end
