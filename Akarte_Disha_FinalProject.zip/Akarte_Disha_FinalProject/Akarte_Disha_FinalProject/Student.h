//
//  Student.h
//  Akarte_Disha_FinalProject
//
//  Created by Disha Akarte on 4/10/17.
//  Copyright © 2017 Disha Akarte. All rights reserved.
//

#ifndef Student_h
#define Student_h

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import "Schedule.h"

@class Login;

@interface Student : NSObject

@property (nonatomic) NSInteger studentId;
//@property (strong,nonatomic) Login *login;
@property (strong,nonatomic) NSString *firstName;
@property (strong,nonatomic) NSString *lastName;
@property (strong,nonatomic) NSString *NUID;
@property (strong,nonatomic) NSString *phone;
@property (strong,nonatomic) UIImage *photo;
@property (strong,atomic) NSString *fine;
@property (strong, nonatomic) NSMutableArray<Schedule *> *listOfBookings;

@end


#endif /* Student_h */
