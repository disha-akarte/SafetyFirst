//
//  VehicleRegistrationController.h
//  Akarte_Disha_FinalProject
//
//  Created by Disha Akarte on 4/10/17.
//  Copyright © 2017 Disha Akarte. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface VehicleRegistrationController : UIViewController<UINavigationControllerDelegate, UITextFieldDelegate>

@property (weak, nonatomic) IBOutlet UITextField *vehivcleNumber;
@property (weak, nonatomic) IBOutlet UITextField *vehicleCapacity;
@property (weak, nonatomic) IBOutlet UITextField *vehicleUsername;
@property (weak, nonatomic) IBOutlet UITextField *vehiclePassword;
@property (weak, nonatomic) IBOutlet UITextField *adminAccessCode;

- (IBAction)BackToOptions:(id)sender;
- (IBAction)SaveVehicleDetails:(id)sender;

@end
