//
//  UserProfileViewController.h
//  Akarte_Disha_FinalProject
//
//  Created by Disha Akarte on 4/14/17.
//  Copyright © 2017 Disha Akarte. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Student.h"


@interface UserProfileViewController : UIViewController

@property Student *student;
@property (weak, nonatomic) IBOutlet UITextField *firstnamefield;
@property (weak, nonatomic) IBOutlet UITextField *lastnamefield;
@property (weak, nonatomic) IBOutlet UITextField *nuidfield;
@property (weak, nonatomic) IBOutlet UITextField *phonefield;
@property (weak, nonatomic) IBOutlet UITextField *fineField;

@property (weak, nonatomic) IBOutlet UIImageView *barCodeView;

- (IBAction)logout:(id)sender;
@property (weak, nonatomic) IBOutlet UIImageView *profilePhoto;

@end
