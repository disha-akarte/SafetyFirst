//
//  Vehice.m
//  Akarte_Disha_FinalProject
//
//  Created by Disha Akarte on 4/18/17.
//  Copyright © 2017 Disha Akarte. All rights reserved.
//

#import "Vehicle.h"

@implementation Vehicle

@synthesize vehicleId,vehicleCapacity,vehicleNumber,login;

@end
