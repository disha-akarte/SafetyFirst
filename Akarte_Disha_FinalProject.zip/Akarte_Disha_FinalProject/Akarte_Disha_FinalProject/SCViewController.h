//
//  ScannerViewController.h
//  Akarte_Disha_FinalProject
//
//  Created by Disha Akarte on 4/29/17.
//  Copyright © 2017 Disha Akarte. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SCViewController : UIViewController

@end
