//
//  BookingDetailsViewController.m
//  Akarte_Disha_FinalProject
//
//  Created by Disha Akarte on 4/26/17.
//  Copyright © 2017 Disha Akarte. All rights reserved.
//

#import "BookingDetailsViewController.h"

@interface BookingDetailsViewController ()

@end

@implementation BookingDetailsViewController
@synthesize status, vehicleNumber, bookingDate, bookingTime, schedule,listOfBookings, index;

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.schedule = [self.listOfBookings objectAtIndex:index];
    
    self.bookingTime.text = self.schedule.departureTime;
    self.bookingDate.text = self.schedule.departureDate;
    Vehicle *v = [[Vehicle alloc]init];
    v= self.schedule.vehicle;
    self.vehicleNumber.text = v.vehicleNumber;
    self.status.text = @"Confirmed";
    
    
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

- (IBAction)back:(id)sender {
    [self dismissViewControllerAnimated:YES completion:nil];
}
@end
