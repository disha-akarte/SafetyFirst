//
//  BookingDetailsViewController.h
//  Akarte_Disha_FinalProject
//
//  Created by Disha Akarte on 4/26/17.
//  Copyright © 2017 Disha Akarte. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Schedule.h"
#import "Vehicle.h"

@interface BookingDetailsViewController : UIViewController<UINavigationControllerDelegate>

@property (strong, atomic) Schedule *schedule;
@property (weak, nonatomic) IBOutlet UITextField *bookingDate;
@property (weak, nonatomic) IBOutlet UITextField *bookingTime;
@property (weak, nonatomic) IBOutlet UITextField *vehicleNumber;
@property (weak, nonatomic) IBOutlet UITextField *status;
@property NSInteger index;

@property (strong, nonatomic)  NSMutableArray<Schedule*> *listOfBookings;
- (IBAction)back:(id)sender;

@end
