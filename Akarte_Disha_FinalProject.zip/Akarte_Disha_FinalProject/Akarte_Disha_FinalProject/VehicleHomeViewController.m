//
//  VehicleHomeViewController.m
//  Akarte_Disha_FinalProject
//
//  Created by Disha Akarte on 4/17/17.
//  Copyright © 2017 Disha Akarte. All rights reserved.
//

#import "VehicleHomeViewController.h"
#import "VehicleDetailsViewController.h"
#import "VehicleSchedulesViewController.h"

@interface VehicleHomeViewController ()

@end

@implementation VehicleHomeViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    

    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
    if([segue.identifier isEqualToString:@"view_vehicle_details"]){
        VehicleDetailsViewController *vd = (VehicleDetailsViewController *)[segue destinationViewController];
        vd.login = self.login;
        vd.vehicle = self.vehicle;
    }
    else if([segue.identifier isEqualToString:@"view_schedules"]){
        VehicleSchedulesViewController *vs = (VehicleSchedulesViewController *)[segue destinationViewController];
        vs.vehicle = self.vehicle;
        
    }
}


- (IBAction)viewDetails:(id)sender {
    [self performSegueWithIdentifier:@"view_vehicle_details" sender:self];
}

- (IBAction)viewSchedules:(id)sender {
    [self performSegueWithIdentifier:@"view_schedules" sender:self];
}

- (IBAction)logout:(id)sender {
    [self dismissViewControllerAnimated:YES completion:nil];
}
@end
