//
//  Admin.h
//  Akarte_Disha_FinalProject
//
//  Created by Disha Akarte on 4/19/17.
//  Copyright © 2017 Disha Akarte. All rights reserved.
//

#ifndef Admin_h
#define Admin_h
#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@class Login;

@interface Admin : NSObject

@property (nonatomic) NSInteger adminId;
@property (strong,nonatomic) Login *login;
@property (strong,nonatomic) NSString *accesscode;


@end



#endif /* Admin_h */
