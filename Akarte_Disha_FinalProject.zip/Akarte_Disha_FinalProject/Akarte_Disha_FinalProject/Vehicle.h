//
//  Vehicle.h
//  Akarte_Disha_FinalProject
//
//  Created by Disha Akarte on 4/18/17.
//  Copyright © 2017 Disha Akarte. All rights reserved.
//


#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@class Login;

@interface Vehicle : NSObject

@property (nonatomic) NSInteger vehicleId;
@property (strong,nonatomic) Login *login;
@property (strong,nonatomic) NSString *vehicleNumber;
@property (strong,nonatomic) NSString *vehicleCapacity;

@end

