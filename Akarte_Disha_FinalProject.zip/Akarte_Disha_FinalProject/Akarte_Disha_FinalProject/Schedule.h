//
//  Schedule.h
//  Akarte_Disha_FinalProject
//
//  Created by Disha Akarte on 4/19/17.
//  Copyright © 2017 Disha Akarte. All rights reserved.
//

#ifndef Schedule_h
#define Schedule_h
#import <Foundation/Foundation.h>


@class Vehicle,Student;

@interface Schedule : NSObject

@property (nonatomic) NSString *scheduleId;
@property (strong,nonatomic) NSString *departureTime;
@property (strong,nonatomic) NSString *departureDate;
@property (strong, nonatomic) Vehicle *vehicle;
@property (strong, nonatomic) NSMutableArray<Student *>* riders;


@end




#endif /* Schedule_h */
