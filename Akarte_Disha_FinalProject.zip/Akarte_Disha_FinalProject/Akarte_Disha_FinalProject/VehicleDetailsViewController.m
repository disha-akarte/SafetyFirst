//
//  VehicleDetailsViewController.m
//  Akarte_Disha_FinalProject
//
//  Created by Disha Akarte on 4/27/17.
//  Copyright © 2017 Disha Akarte. All rights reserved.
//

#import "VehicleDetailsViewController.h"

@interface VehicleDetailsViewController ()

@end

@implementation VehicleDetailsViewController
@synthesize login, vehicle;

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.vehiNumber.text = self.vehicle.vehicleNumber;
    self.vehCapacity.text = self.vehicle.vehicleCapacity;
    self.vehUsername.text = self.login.username;
    
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

- (IBAction)logout:(id)sender {
    [self.presentingViewController.presentingViewController dismissViewControllerAnimated: true completion: nil];
}
- (IBAction)back:(id)sender {
    [self dismissViewControllerAnimated:YES completion:nil];
}
@end
