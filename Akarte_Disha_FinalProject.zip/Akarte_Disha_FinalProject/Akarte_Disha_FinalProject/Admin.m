//
//  Admin.m
//  Akarte_Disha_FinalProject
//
//  Created by Disha Akarte on 4/19/17.
//  Copyright © 2017 Disha Akarte. All rights reserved.
//


#import <Foundation/Foundation.h>
#import "Admin.h"

@implementation Admin

@synthesize adminId,accesscode;

-(id)init
{
    self = [super init];

    return self;
}

@end
