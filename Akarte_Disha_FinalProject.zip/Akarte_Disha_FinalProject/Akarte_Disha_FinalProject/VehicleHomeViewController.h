//
//  VehicleHomeViewController.h
//  Akarte_Disha_FinalProject
//
//  Created by Disha Akarte on 4/17/17.
//  Copyright © 2017 Disha Akarte. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Login.h"

@interface VehicleHomeViewController : UIViewController

@property (strong, nonatomic)  Login* login;
@property (strong, nonatomic) Vehicle* vehicle;

- (IBAction)viewDetails:(id)sender;

- (IBAction)viewSchedules:(id)sender;
- (IBAction)logout:(id)sender;

@end
