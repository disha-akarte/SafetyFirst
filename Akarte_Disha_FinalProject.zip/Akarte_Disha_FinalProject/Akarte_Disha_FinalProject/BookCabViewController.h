//
//  BookCabViewController.h
//  Akarte_Disha_FinalProject
//
//  Created by Disha Akarte on 4/21/17.
//  Copyright © 2017 Disha Akarte. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Student.h"
#import "Schedule.h"
#import "Vehicle.h"
#import "BookingsListTableViewController.h"


@interface BookCabViewController : UIViewController<UIPickerViewDataSource, UIPickerViewDelegate>

@property Student *student;
@property Schedule *schedule;
@property NSMutableArray *dd;
@property NSMutableArray *dt;
@property NSMutableArray *listOfSchedules;
@property BookingsListTableViewController *blvc;

@property (weak, nonatomic) IBOutlet UIPickerView *datePicker;

@property (weak, nonatomic) IBOutlet UIPickerView *timePicker;
- (IBAction)checkAvailability:(id)sender;
@property (weak, nonatomic) IBOutlet UILabel *seatsAvailable;
- (IBAction)book:(id)sender;
- (IBAction)logout:(id)sender;
@property (weak, nonatomic) IBOutlet UIBarButtonItem *bookButton;

@end
