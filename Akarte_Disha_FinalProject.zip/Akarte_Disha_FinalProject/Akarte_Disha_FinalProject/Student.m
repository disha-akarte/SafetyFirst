//
//  Student.m
//  Akarte_Disha_FinalProject
//
//  Created by Disha Akarte on 4/10/17.
//  Copyright © 2017 Disha Akarte. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Student.h"

@implementation Student

@synthesize studentId,firstName,lastName,phone,NUID,photo,listOfBookings,fine;

-(id)init
{
    self = [super init];
    if(self){
        listOfBookings =[[NSMutableArray alloc]init];
    }
    return self;
}

@end
