//
//  AdminHomeViewController.m
//  Akarte_Disha_FinalProject
//
//  Created by Disha Akarte on 4/19/17.
//  Copyright © 2017 Disha Akarte. All rights reserved.
//

#import "AdminHomeViewController.h"
#import "Schedule.h"
#import "Vehicle.h"

@interface AdminHomeViewController ()

@end

@implementation AdminHomeViewController
@synthesize vehicleList;

- (void)viewDidLoad {
    [super viewDidLoad];
    NSLog(@"List of of vehicles : %@",self.vehicleList);
    
    self.vehicleNumberPicker.dataSource = self;
    self.vehicleNumberPicker.delegate = self;
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

- (IBAction)submitSchedule:(id)sender {
    
    /*if([self.vehicleNumber.text isEqual:@""]){
        [self alertStatus:@"Please fill out all the details properly":@"Enter valid values in input fields" :0];
    }
    else{*/
        Schedule* schedule= [[Schedule alloc]init];
        NSDate *dateSelected = self.schedule_date.date;
        schedule.departureDate = dateSelected;
        
        
        NSDateFormatter *df = [[NSDateFormatter alloc] init]; //Will release itself for us
        [df setDateFormat:@"yyyy-MM-dd"];
        NSString* dateString = [df stringFromDate:schedule.departureDate ]; //Simplified the code
        
        NSLog(@"Departure Date : %@",dateString);
        
        [df setDateFormat:@"h:mm a"];
        NSString *timeString = [df stringFromDate:schedule.departureDate ];
        
        NSLog(@"Departure Time : %@",timeString);
        
        Vehicle *v= [[Vehicle alloc]init];
        schedule.vehicle = v;
        NSInteger roleIndex = [_vehicleNumberPicker selectedRowInComponent:0];
        NSString* vehicleNumber=vehicleList[roleIndex];
        NSLog(@"Vehicle Number selected : %@",vehicleNumber);
        
        schedule.vehicle.vehicleNumber = vehicleNumber;
        schedule.vehicle.vehicleCapacity = @"10";
        
        NSString* Url = @"http://localhost:8080/safetyfirst/addSchedule";
        NSURL *url = [NSURL URLWithString:Url];
        
        NSDictionary *vehicleInfo = [NSDictionary dictionaryWithObjectsAndKeys:
                                     vehicleNumber,@"vehicleNumber",
                                     @"10",@"capacity",
                                     nil];
        
        NSLog(@"Vehicle Info is : %@", vehicleInfo);


        NSDictionary *scheduleInfo = [NSDictionary dictionaryWithObjectsAndKeys:
                                     dateString,@"departureDate",
                                     timeString,@"departureTime",
                                     vehicleInfo,@"vehicle",
                                     nil];
        
        NSLog(@"Schedule Info is : %@", scheduleInfo);
        
        NSData *postData = [NSJSONSerialization dataWithJSONObject:scheduleInfo options:NSJSONWritingPrettyPrinted error:nil];
        
        
        NSString *jsonString = [[NSString alloc] initWithData:postData encoding:NSUTF8StringEncoding];
        NSLog(@"jSON Data is : %@", jsonString);
        
        NSString *postLength = [NSString stringWithFormat:@"%lu", (unsigned long)[postData length]];
        
        NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:url];
        [request setHTTPMethod:@"POST"];
        [request setValue:postLength forHTTPHeaderField:@"Content-Length"];
        [request setValue:@"application/json" forHTTPHeaderField:@"Accept"];
        [request setValue:@"application/json" forHTTPHeaderField:@"Content-Type"];
        [request setHTTPBody:postData];
        
        NSLog(@"Request is : %@", request);
        
        NSError *error = [[NSError alloc] init];
        
        NSHTTPURLResponse *response = nil;
        
        NSData *urlData=[NSURLConnection sendSynchronousRequest:request returningResponse:&response error:&error];
        
        
        NSLog(@"Response Code : %ld", (long)[response statusCode]);
        
        if ([response statusCode] >= 200 && [response statusCode] < 300)
        {
            NSError *error = nil;
            NSDictionary *jsonData = [NSJSONSerialization
                                      JSONObjectWithData:urlData
                                      options:NSJSONReadingMutableContainers
                                      error:&error];
            NSLog(@"Response is : %@", jsonData);
            
            NSInteger success = [jsonData[@"scheduleID"] integerValue];
            if(success >= 1)
            {
                [self alertStatus:@"Saved Successfully":@"" :0];
                [self dismissViewControllerAnimated:YES completion:nil];
            }
            else{
                [self alertStatus:@"Please fill out the details properly":@"Try with valid entries" :0];
            }
        }
        else {
            
            [self alertStatus:@"Connection Failed" :@"Connection Failed!" :0];
        }
        
//    }

}


// The number of columns of data
- (int)numberOfComponentsInPickerView:(UIPickerView *)pickerView
{
    return 1;
}


// The number of rows of data
- (int)pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component
{
    return self.vehicleList.count;
    
}

// The data to return for the row and component (column) that's being passed in
- (NSString*)pickerView:(UIPickerView *)pickerView titleForRow:(NSInteger)row forComponent:(NSInteger)component
{
    return self.vehicleList[row];
}

// Catpure the picker view selection
- (void)pickerView:(UIPickerView *)pickerView didSelectRow:(NSInteger)row inComponent:(NSInteger)component
{
    
}

- (void) alertStatus:(NSString *)msg :(NSString *)title :(int) tag
{
    UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:title
                                                        message:msg
                                                       delegate:self
                                              cancelButtonTitle:@"Ok"
                                              otherButtonTitles:nil, nil];
    alertView.tag = tag;
    [alertView show];
}


- (IBAction)backToHome:(id)sender {
    [self dismissViewControllerAnimated:YES completion:nil];
}
@end
