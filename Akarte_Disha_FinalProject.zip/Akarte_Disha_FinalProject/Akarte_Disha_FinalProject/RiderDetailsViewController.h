//
//  RiderDetailsViewController.h
//  Akarte_Disha_FinalProject
//
//  Created by Disha Akarte on 4/28/17.
//  Copyright © 2017 Disha Akarte. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Student.h"

@interface RiderDetailsViewController : UIViewController
@property (weak, nonatomic) IBOutlet UITextField *firstNameText;
@property (weak, nonatomic) IBOutlet UITextField *lastNameText;
@property (weak, nonatomic) IBOutlet UITextField *nuidText;
@property (weak, nonatomic) IBOutlet UITextField *phoneText;
@property NSMutableArray<Student*> *listOfRiders;
@property NSInteger index;

@property Student *student;
- (IBAction)boardedIndicator:(id)sender;
- (IBAction)back:(id)sender;
@property (weak, nonatomic) IBOutlet UISwitch *boardIndicator;

@end
