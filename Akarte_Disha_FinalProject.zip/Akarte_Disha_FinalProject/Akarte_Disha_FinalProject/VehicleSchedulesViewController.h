//
//  VehicleSchedulesViewController.h
//  Akarte_Disha_FinalProject
//
//  Created by Disha Akarte on 4/27/17.
//  Copyright © 2017 Disha Akarte. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Student.h"
#import "Schedule.h"
#import "Vehicle.h"


@interface VehicleSchedulesViewController : UIViewController<UINavigationBarDelegate, UINavigationControllerDelegate, UIPickerViewDataSource, UIPickerViewDelegate,UITableViewDelegate, UITableViewDataSource>


@property Student *student;
@property Schedule *schedule;
@property Vehicle *vehicle;
@property NSMutableArray *dd;
@property NSMutableArray *dt;
@property NSMutableArray *listOfSchedules;

@property NSMutableArray<Student*> *listOfRiders;

@property (weak, nonatomic) IBOutlet UIPickerView *schedulePicker;
@property (weak, nonatomic) IBOutlet UIPickerView *timePicker;

- (IBAction)fetchList:(id)sender;

@property (weak, nonatomic) IBOutlet UITableView *riderTableView;

- (IBAction)logout:(id)sender;
- (IBAction)back:(id)sender;

@end
