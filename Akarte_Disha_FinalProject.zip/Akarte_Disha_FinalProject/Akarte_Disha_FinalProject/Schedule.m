//
//  Schedule.m
//  Akarte_Disha_FinalProject
//
//  Created by Disha Akarte on 4/19/17.
//  Copyright © 2017 Disha Akarte. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Schedule.h"

@implementation Schedule

@synthesize vehicle,departureDate,departureTime,scheduleId,riders;

-(id)init
{
    self = [super init];
    if(self){
        riders =[[NSMutableArray alloc]init];
    }
    return self;
}

@end
