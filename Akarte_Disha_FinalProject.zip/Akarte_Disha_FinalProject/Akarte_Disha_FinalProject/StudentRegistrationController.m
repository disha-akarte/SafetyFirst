//
//  StudentRegistrationController.m
//  Akarte_Disha_FinalProject
//
//  Created by Disha Akarte on 4/10/17.
//  Copyright © 2017 Disha Akarte. All rights reserved.
//

#import "StudentRegistrationController.h"
#import "ViewController.h"
#import "Student.h"
#import "Login.h"


@interface StudentRegistrationController ()

@end

@implementation StudentRegistrationController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    
    
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
    if ([segue.identifier isEqualToString:@"cancelStudentRegistration"]) {
        ViewController *vc = segue.destinationViewController;
    }
}


- (IBAction)saveStudent:(id)sender {
    
    if([self.username.text isEqual:@""]||[self.password.text isEqual:@""]||[self.firstName.text isEqual:@""]||[self.lastName.text isEqual:@""]||[self.phone.text isEqual:@""]||[self.NUID.text isEqual:@""]){
        [self alertStatus:@"Please fill out all the details properly":@"Enter valid values in text fields" :0];
    }
    else{
        Login* login= [[Login alloc]init];
        login.username=self.username.text;
        login.password=self.password.text;
        login.role=@"student";
        
        Student *student = [[Student alloc]init];
        student.firstName = self.firstName.text;
        student.lastName = self.lastName.text;
        student.NUID = self.NUID.text;
        student.phone = self.phone.text;
        
        // NSString *photoString = [self getStringFromImage:[self.StudentPhotoView image]];
        //NSLog(@"Photo String : %@",photoString);
        
        NSString* Url = @"http://localhost:8080/safetyfirst/addStudent";
        NSURL *url = [NSURL URLWithString:Url];
        
        NSDictionary *studentInfo = [NSDictionary dictionaryWithObjectsAndKeys:
                                     [NSNumber numberWithInt:1],@"loginid",
                                     [self.firstName text],@"firstname",
                                     [self.lastName text],@"lastname",
                                     [self.phone text],@"phone",
                                     [self.NUID text],@"nuid",
                                     [self.username text],@"username",
                                     [self.password text],@"password",
                                     nil];
        
        NSLog(@"Student Info is : %@", studentInfo);
        
        NSData *postData = [NSJSONSerialization dataWithJSONObject:studentInfo options:NSJSONWritingPrettyPrinted error:nil];
        
        
        NSString *jsonString = [[NSString alloc] initWithData:postData encoding:NSUTF8StringEncoding];
        NSLog(@"jSON Data is : %@", jsonString);
        
        NSString *postLength = [NSString stringWithFormat:@"%lu", (unsigned long)[postData length]];
        
        NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:url];
        [request setHTTPMethod:@"POST"];
        [request setValue:postLength forHTTPHeaderField:@"Content-Length"];
        [request setValue:@"application/json" forHTTPHeaderField:@"Accept"];
        [request setValue:@"application/json" forHTTPHeaderField:@"Content-Type"];
        [request setHTTPBody:postData];
        
        NSLog(@"Request is : %@", request);
        
        NSError *error = [[NSError alloc] init];
        
        NSHTTPURLResponse *response = nil;
        
        NSData *urlData=[NSURLConnection sendSynchronousRequest:request returningResponse:&response error:&error];
        
        
        NSLog(@"Response Code : %ld", (long)[response statusCode]);
        
        if ([response statusCode] >= 200 && [response statusCode] < 300)
        {
            NSError *error = nil;
            NSDictionary *jsonData = [NSJSONSerialization
                                      JSONObjectWithData:urlData
                                      options:NSJSONReadingMutableContainers
                                      error:&error];
            NSLog(@"Response is : %@", jsonData);
            
            NSInteger success = [jsonData[@"loginid"] integerValue];
            if(success >= 1)
            {
                [self alertStatus:@"Saved Successfully":@"" :0];
                [self dismissViewControllerAnimated:YES completion:nil];
            }
            else{
                [self alertStatus:@"Save error!":@"Could not save" :0];
            }
        }
        else {
            
            [self alertStatus:@"Connection Failed" :@"Connection Failed!" :0];
        }
        
    }

}

- (IBAction)browseImages:(id)sender {
    UIImagePickerController *imagePicker = [[UIImagePickerController alloc] init];
    imagePicker.modalPresentationStyle = UIModalPresentationCurrentContext;
    imagePicker.sourceType = UIImagePickerControllerSourceTypePhotoLibrary;
    imagePicker.delegate = self;
    
    self.imagePickerController = imagePicker;
    [self presentViewController:self.imagePickerController animated:YES completion:nil];
}

- (IBAction)goBack:(id)sender {
    [self dismissViewControllerAnimated:YES completion:nil];
}


- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary *)info {
    
    UIImage *image = info[UIImagePickerControllerOriginalImage];
    self.StudentPhotoView.image = image;
    
    [picker dismissViewControllerAnimated:YES completion:NULL];

    
}


- (void)image:(UIImage *)image didFinishSavingWithError:(NSError *)error contextInfo:(void *)contextInfo
{
    UIAlertController *alert;
    
    // Unable to save the image
    if (error) {
        alert = [UIAlertController alertControllerWithTitle:@"Error" message:@"Unable to save image to Photo Album." preferredStyle:UIAlertControllerStyleAlert];
    }
    // All is well
    else {
        alert = [UIAlertController alertControllerWithTitle:@"Error" message:@"Image saved to Photo Album." preferredStyle:UIAlertControllerStyleAlert];
        
    }
    
    UIAlertAction* defaultAction = [UIAlertAction actionWithTitle:@"OK" style:
                                    UIAlertActionStyleDefault handler:^(UIAlertAction * action) {}];
    [alert addAction:defaultAction];
    [self presentViewController:alert animated:YES completion:nil];
    
}

- (void) alertStatus:(NSString *)msg :(NSString *)title :(int) tag
{
    UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:title
                                                        message:msg
                                                       delegate:self
                                              cancelButtonTitle:@"Ok"
                                              otherButtonTitles:nil, nil];
    alertView.tag = tag;
    [alertView show];
}

-(NSString *)getStringFromImage:(UIImage *)image{
    if(image){
        NSData *dataObj = UIImagePNGRepresentation(image);
        //[appDelegate showAlert:@"Data Size" message:[NSString stringWithFormat:@"Data length = %lu",(unsigned long)dataObj.length]];
        return [dataObj base64EncodedStringWithOptions:0];
    } else {
        return @"";
    }
}


@end
