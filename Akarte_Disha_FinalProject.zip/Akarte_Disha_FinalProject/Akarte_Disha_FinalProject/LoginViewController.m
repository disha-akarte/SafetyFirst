//
//  LoginViewController.m
//  Akarte_Disha_FinalProject
//
//  Created by Disha Akarte on 4/1/17.
//  Copyright © 2017 Disha Akarte. All rights reserved.
//

#import "LoginViewController.h"
#import "SignUpOptionViewController.h"
#import "Student.h"
#import "UserProfileViewController.h"
#import "UserHomeViewController.h"
#import "VehicleHomeViewController.h"
#import "AdminHomeViewController.h"
#import "BookCabViewController.h"
#import "BookingsListTableViewController.h"


@interface LoginViewController ()

@end

@implementation LoginViewController
@synthesize login,student;
@synthesize headerImage,vehList;

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    UIImage *headerPhoto = [UIImage imageNamed:@"redlogo.png"];
    headerImage.image = headerPhoto;
    self.login=[[Login alloc]init];
    self.login.student=[[Student alloc]init];
    self.vehicle = [[Vehicle alloc]init];
    
    
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(dismissKeyboard)];
    
    [self.view addGestureRecognizer:tap];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


#pragma mark - Navigation



- (IBAction)signin:(id)sender {
    NSString* Url = @"http://localhost:8080/safetyfirst/";
    
    NSInteger success = 0;
    @try {
        
        if([[self.usernameField text] isEqualToString:@""] || [[self.passwordField text] isEqualToString:@""] ) {
            [self alertStatus:@"Please enter Email and Password" :@"Sign in Failed!" :0];
        }
        else {
            
            NSString *post =[[NSString alloc] initWithFormat:@"username=%@&password=%@",[self.usernameField text],[self.passwordField text]];
            
            NSString *stringUrl = [NSString stringWithFormat:@"%@login",Url];
            
            NSURL *url = [NSURL URLWithString:stringUrl];
          
        
            NSDictionary *loginfo = [NSDictionary dictionaryWithObjectsAndKeys:
                                     [NSNumber numberWithInt:1],@"loginid",
                                     [self.usernameField text],@"username",
                                     [self.passwordField text],@"password",
                                     nil];
            
            NSLog(@"Login Info is : %@", loginfo);


            NSData *postData = [NSJSONSerialization dataWithJSONObject:loginfo options:NSJSONWritingPrettyPrinted error:nil];
            
            NSString *postLength = [NSString stringWithFormat:@"%lu", (unsigned long)[postData length]];
       
            NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:url cachePolicy:NSURLRequestReloadIgnoringLocalCacheData timeoutInterval:10];
            [request setHTTPMethod:@"POST"];
            [request setValue:postLength forHTTPHeaderField:@"Content-Length"];
            [request setValue:@"application/json" forHTTPHeaderField:@"Accept"];
            [request setValue:@"application/json" forHTTPHeaderField:@"Content-Type"];
            [request setHTTPBody:postData];
            
            NSLog(@"Request is : %@", request);
            
            NSError *error = [[NSError alloc] init];
            
            NSHTTPURLResponse *response = nil;
            
            NSData *urlData=[NSURLConnection sendSynchronousRequest:request returningResponse:&response error:&error];
            NSLog(@"Response Code : %ld", (long)[response statusCode]);

            
            if ([response statusCode] >= 200 && [response statusCode] < 300)
            {
                
                NSString *responseData = [[NSString alloc]initWithData:urlData encoding:NSUTF8StringEncoding];
                NSLog(@"Response ==> %@", responseData);
                
                NSError *error = nil;
                NSDictionary *jsonData = [NSJSONSerialization
                                          JSONObjectWithData:urlData
                                          options:NSJSONWritingPrettyPrinted
                                          error:&error];
                
                
                
                success = [jsonData[@"loginid"] integerValue];
                NSString* role = jsonData[@"role"];
                
                if(success >= 1)
                {
                    self.login.loginid = success;
                    self.login.username = jsonData[@"username"];
                    self.login.password=jsonData[@"password"];
                    self.login.role=role;
                    
                    
                    if([role isEqualToString:@"Admin"]){
                        self.vehList =  jsonData[@"vehicleList"];
                        self.vehList = [self.vehList valueForKey:@"vehicleNumber"];
                        [self performSegueWithIdentifier:@"adminLoginSuccess" sender:self];
                    }
                    
                    else if([role isEqualToString:@"Vehicle"]){
                        self.vehicle.vehicleCapacity = jsonData[@"capacity"];
                        self.vehicle.vehicleNumber = jsonData[@"vehicleNumber"];
                        [self performSegueWithIdentifier:@"vehicle_login_success" sender:self];
                        
                    }
                    else{
                        student = [[Student alloc]init];
                        student.firstName = jsonData[@"firstname"];
                        student.lastName = jsonData[@"lastname"];
                        student.NUID = jsonData[@"nuid"];
                        student.phone = jsonData[@"phone"];
                        student.fine = jsonData[@"fine"];
                        self.login.student = student;
                        
                        NSDictionary *r = jsonData[@"bookings"];
                        
                        for(NSDictionary *dict in r){
                            
                            Schedule *sch = [[Schedule alloc]init];
                            sch.scheduleId = dict[@"scheduleID"];
                            sch.departureTime = dict[@"departureTime"];
                            sch.departureDate = dict[@"departureDate"];
                            
                            Vehicle *v = [[Vehicle alloc]init];
                            v.vehicleNumber = dict[@"vehicleNumber"];
                            sch.vehicle = v;
                            [self.login.student.listOfBookings addObject:sch];
                            
                        }

                        [self performSegueWithIdentifier:@"login_success" sender:self];
                        
                        
                    }
                    
                } else {
                    
                    NSString *error_msg = (NSString *) jsonData[@"error_message"];
                    [self alertStatus:error_msg :@"Sign in Failed!" :0];
                }
                
            } else {
                
                [self alertStatus:@"Connection Failed" :@"Connection Failed!" :0];
            }
        }
    }
    
    @catch (NSException * e) {
        NSLog(@"Exception: %@", e);
        [self alertStatus:@"Sign in Failed." :@"Error!" :0];
    }
    

}

//Get object from json data

- (void) alertStatus:(NSString *)msg :(NSString *)title :(int) tag
{
    UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:title
                                                        message:msg
                                                       delegate:self
                                              cancelButtonTitle:@"Ok"
                                              otherButtonTitles:nil, nil];
    alertView.tag = tag;
    [alertView show];
}


- (IBAction)reset:(id)sender {
    self.usernameField.text = @"";
    self.passwordField.text = @"";
}

-(IBAction)signup:(id)sender{
    [self performSegueWithIdentifier:@"SignUpOptions" sender:self];
}


- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
   if([segue.identifier isEqualToString:@"login_success"]){
       
       
       UserHomeViewController *userHome= (UserHomeViewController *)[segue destinationViewController];
       userHome.login =self.login;
       
       UserProfileViewController *userprofile=[userHome viewControllers][0];
       userprofile.student = self.login.student;
       
       BookCabViewController *bookcab=[userHome viewControllers][1];
       bookcab.student = self.login.student;
       
       UINavigationController *navigationController = [userHome viewControllers][2];
       BookingsListTableViewController *bookingsListViewController = [navigationController viewControllers][0];
       bookingsListViewController.student = self.login.student;
       bookingsListViewController.listOfBookings = self.login.student.listOfBookings;

    }
   else if ([segue.identifier isEqualToString:@"vehicle_login_success"]) {
       VehicleHomeViewController *vehHome = (VehicleHomeViewController *)[segue destinationViewController];
       vehHome.login = self.login;
       vehHome.vehicle = self.vehicle;
 
   }
    
   else if ([segue.identifier isEqualToString:@"SignUpOptions"]) {
       SignUpOptionViewController *viewdetails = segue.destinationViewController;
   }
    
    
   else if ([segue.identifier isEqualToString:@"adminLoginSuccess"]) {
       AdminHomeViewController *adminHome = segue.destinationViewController;
       adminHome.vehicleList = self.vehList;
       
   }

}

-(NSMutableArray *) fetchVehicleInfo{
    
    NSString* Url = @"http://localhost:8080/safetyfirst/getSchedule";
    NSURL *url = [NSURL URLWithString:Url];
    
    NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:url cachePolicy:NSURLRequestReloadIgnoringLocalCacheData timeoutInterval:10];
    [request setHTTPMethod:@"GET"];
    
    NSError *error = [[NSError alloc] init];
    
    NSHTTPURLResponse *response = nil;
    
    NSData *urlData=[NSURLConnection sendSynchronousRequest:request returningResponse:&response error:&error];
    
    NSLog(@"Response Code : %ld", (long)[response statusCode]);
    
    if ([response statusCode] >= 200 && [response statusCode] < 300)
    {
        NSError *error = nil;
        NSDictionary *jsonData = [NSJSONSerialization
                                  JSONObjectWithData:urlData
                                  options:NSJSONReadingMutableContainers
                                  error:&error];
        NSLog(@"Response is : %@", jsonData);
        
        
        NSMutableArray *listOfSchedules = [[NSMutableArray alloc]init];
        for(NSDictionary * dict in jsonData)
        {
            Schedule *sch = [[Schedule alloc]init];
            sch.scheduleId = [dict valueForKey:@"scheduleID"];
            sch.departureTime = [dict valueForKey:@"departureTime"];
            sch.departureDate = [dict valueForKey:@"departureDate"];
            
            Vehicle *v = [[Vehicle alloc]init];
            v.vehicleId = [[[dict valueForKey:@"vehicleID"]init] integerValue];
            v.vehicleCapacity = [dict valueForKey:@"capacity"];
            v.vehicleNumber = [dict valueForKey:@"vehicleNumber"];
            v.vehicleId = [[dict valueForKey:@"loginid"] integerValue];
            
            NSString *r = [dict valueForKey:@"riders"];
            
            
            for(NSDictionary * dict in r)
            {
                Student *stu = [[Student alloc]init];
                stu.studentId = [[dict valueForKey:@"studentid"] integerValue];
                stu.firstName = [dict valueForKey:@"firstname"];
                stu.lastName = [dict valueForKey:@"lastname"];
                stu.NUID = [dict valueForKey:@"nuid"];
                stu.phone = [dict valueForKey:@"phone"];
                [sch.riders addObject:stu];
            }
            
            NSLog(@"Riders in the cab are : %lu",(unsigned long)sch.riders.count);
            
            
            sch.vehicle = v;
            
            [listOfSchedules addObject:sch];
        }
        return listOfSchedules;
        
    }
    else{
        [self alertStatus:@"Connection Failed" :@"Connection Failed!" :0];
        return nil;
    }

}

-(void)dismissKeyboard
{
    [self.usernameField resignFirstResponder];
    [self.passwordField resignFirstResponder];
}

- (IBAction)callNUPD:(id)sender {
    
    
    NSString *phNo = @"+18572689331";
    NSURL *phoneUrl = [NSURL URLWithString:[NSString  stringWithFormat:@"telprompt:%@",phNo]];
    
    if ([[UIApplication sharedApplication] canOpenURL:phoneUrl]) {
        [[UIApplication sharedApplication] openURL:phoneUrl];
    } else
    {
        [self alertStatus:@"Call Failed" :@"Call facility unavailable!" :0];
    }
}
@end
