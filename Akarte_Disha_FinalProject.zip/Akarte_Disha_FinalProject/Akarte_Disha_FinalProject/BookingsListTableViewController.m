//
//  BookingsListTableViewController.m
//  Akarte_Disha_FinalProject
//
//  Created by Disha Akarte on 4/25/17.
//  Copyright © 2017 Disha Akarte. All rights reserved.
//

#import "BookingsListTableViewController.h"
#import "BookingDetailsViewController.h"
#import "BookCabViewController.h"

@interface BookingsListTableViewController ()

@end

@implementation BookingsListTableViewController
@synthesize listOfBookings,student,bookingsTableView,passedSchedule;


- (void)viewDidLoad {
    [super viewDidLoad];
    self.tabBarController.delegate = self;
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)viewWillAppear:(BOOL)animated{
    
    [bookingsTableView reloadData];
}

#pragma mark - Table view data source

// Pass the row to another view controller to display the details
-(void) tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    UITableViewCell *cell=[tableView cellForRowAtIndexPath:indexPath];
    
    NSString *departDate = cell.textLabel.text;
    NSString *departTime = cell.detailTextLabel.text;
    
    Boolean flag = false;
    
    for(Schedule *sc in self.student.listOfBookings ){
        NSComparisonResult result1 = [departDate compare:sc.departureDate];
        NSComparisonResult result2 = [departTime compare:sc.departureTime];
        if(result1 == NSOrderedSame && result2==NSOrderedSame) {
            flag = true;
        }
    }
    
    if(flag == false){
        
        UIAlertController* alert = [UIAlertController alertControllerWithTitle:@"Error" message:@"No results found!" preferredStyle:UIAlertControllerStyleAlert];
        
        UIAlertAction* defaultAction = [UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:^(UIAlertAction * action) {}];
        [alert addAction:defaultAction];
        
        [self presentViewController:alert animated:YES completion:nil];
        
    }else
    {
        [self performSegueWithIdentifier:@"viewDetails" sender:self];
    }
    
}


- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return [self.student.listOfBookings count];
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"booking"];
    
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:@"booking"];
    }
    
    Schedule *rh = [self.student.listOfBookings objectAtIndex:indexPath.row];
    cell.accessoryType=UITableViewCellAccessoryDisclosureIndicator;
    cell.textLabel.text = [NSString stringWithFormat:@"%@", rh.departureDate];
    cell.detailTextLabel.text = [NSString stringWithFormat:@"%@", rh.departureTime];
    
    return cell;
    
}




// Override to support conditional editing of the table view.
- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath {
    // Return NO if you do not want the specified item to be editable.
    return YES;
}



// Override to support editing the table view.
- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        // Delete the row from the data source
        Schedule *schedule = [self.student.listOfBookings objectAtIndex:indexPath.row];
        
        [self.student.listOfBookings removeObjectAtIndex:indexPath.row];
        ((BookCabViewController *)self.tabBarController.viewControllers[1]).student = self.student;
        
        NSString* Url = @"http://localhost:8080/safetyfirst/deleteRider";
        NSURL *url = [NSURL URLWithString:Url];
        
        NSDictionary *studentInfo = [NSDictionary dictionaryWithObjectsAndKeys:
                                     self.student.NUID,@"nuid",
                                     self.student.phone,@"phone",
                                     nil];
        
        NSLog(@"Student Info is : %@", studentInfo);
        
        
        NSDictionary *scheduleinfo = [NSDictionary dictionaryWithObjectsAndKeys:
                                      schedule.scheduleId ,@"scheduleID",
                                      nil];
        
        NSLog(@"Schedule Info is : %@", scheduleinfo);
        
        NSDictionary *infoToSend = [NSDictionary dictionaryWithObjectsAndKeys:
                                    scheduleinfo , @"schedule",
                                    studentInfo ,@"student",
                                    nil];
        
        NSLog(@"Request Info is : %@", infoToSend);
        
        NSData *postData = [NSJSONSerialization dataWithJSONObject:infoToSend options:NSJSONWritingPrettyPrinted error:nil];
        
        NSString *postLength = [NSString stringWithFormat:@"%lu", (unsigned long)[postData length]];
        
        NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:url];
        [request setHTTPMethod:@"POST"];
        [request setValue:postLength forHTTPHeaderField:@"Content-Length"];
        [request setValue:@"application/json" forHTTPHeaderField:@"Accept"];
        [request setValue:@"application/json" forHTTPHeaderField:@"Content-Type"];
        [request setHTTPBody:postData];
        
        NSLog(@"Request is : %@", request);
        
        
        NSError *error = [[NSError alloc] init];
        
        NSHTTPURLResponse *response = nil;
        
        NSData *urlData=[NSURLConnection sendSynchronousRequest:request returningResponse:&response error:&error];
        
        NSLog(@"Response Code : %ld", (long)[response statusCode]);
        
        if ([response statusCode] >= 200 && [response statusCode] < 300)
        {
            NSError *error = nil;
            NSDictionary *jsonData = [NSJSONSerialization
                                      JSONObjectWithData:urlData
                                      options:NSJSONReadingMutableContainers
                                      error:&error];
            NSLog(@"Response is : %@", jsonData);
            
            if(jsonData!=nil){
                [self alertStatus:@"Deletion Successful" :@"Booking deleted!" :0];
            }
            else{
                [self alertStatus:@"Deletion failed" :@"Deletion failed!" :0];
            }
        }
        else{
            [self alertStatus:@"Connection Failed" :@"Connection Failed!" :0];
        }

        
        [tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationFade];
    } else if (editingStyle == UITableViewCellEditingStyleInsert) {
        // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
    }   
}


/*
// Override to support rearranging the table view.
- (void)tableView:(UITableView *)tableView moveRowAtIndexPath:(NSIndexPath *)fromIndexPath toIndexPath:(NSIndexPath *)toIndexPath {
}
*/

/*
// Override to support conditional rearranging of the table view.
- (BOOL)tableView:(UITableView *)tableView canMoveRowAtIndexPath:(NSIndexPath *)indexPath {
    // Return NO if you do not want the item to be re-orderable.
    return YES;
}
*/


#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
    if ([[segue identifier] isEqualToString:@"viewDetails"]){
        NSIndexPath *path=[bookingsTableView indexPathForSelectedRow];
        
        BookingDetailsViewController *viewdetails = segue.destinationViewController;
        viewdetails.listOfBookings = self.student.listOfBookings;
        viewdetails.index = path.row;
    }
}


- (IBAction)logout:(id)sender {
    [self dismissViewControllerAnimated:YES completion:nil];
}


- (void) alertStatus:(NSString *)msg :(NSString *)title :(int) tag
{
    UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:title
                                                        message:msg
                                                       delegate:self
                                              cancelButtonTitle:@"Ok"
                                              otherButtonTitles:nil, nil];
    alertView.tag = tag;
    [alertView show];
}
@end
