//
//  RiderDetailsViewController.m
//  Akarte_Disha_FinalProject
//
//  Created by Disha Akarte on 4/28/17.
//  Copyright © 2017 Disha Akarte. All rights reserved.
//

#import "RiderDetailsViewController.h"

@interface RiderDetailsViewController ()

@end

@implementation RiderDetailsViewController
@synthesize student,listOfRiders,firstNameText,lastNameText,nuidText,phoneText,index,boardIndicator;
- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.student = [listOfRiders objectAtIndex:index];
    self.firstNameText.text = self.student.firstName;
    self.lastNameText.text = self.student.lastName;
    self.nuidText.text = self.student.NUID;
    self.phoneText.text = self.student.phone;
    
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

- (IBAction)boardedIndicator:(id)sender {
    if ([self.boardIndicator isOn]) {
        NSLog(@"Student has boarded!");
    } else {
       NSLog(@"Student did not board!");
        
        NSString* Url = @"http://localhost:8080/safetyfirst/addFine";
        NSURL *url = [NSURL URLWithString:Url];
        
        int previousFine = [self.student.fine integerValue];
        int newFine = previousFine+5;
        NSString *newFineString = [NSString stringWithFormat: @"%ld", (long)newFine];
        
        NSDictionary *studentInfo = [NSDictionary dictionaryWithObjectsAndKeys:
                                     [NSNumber numberWithInt:1],@"loginid",
                                     self.student.firstName,@"firstname",
                                     self.student.lastName,@"lastname",
                                     self.student.phone,@"phone",
                                     self.student.NUID,@"nuid",
                                     newFineString,@"fine",
                                     nil];
        
        NSLog(@"Student Info is : %@", studentInfo);
        
        NSData *postData = [NSJSONSerialization dataWithJSONObject:studentInfo options:NSJSONWritingPrettyPrinted error:nil];
        
        
        NSString *jsonString = [[NSString alloc] initWithData:postData encoding:NSUTF8StringEncoding];
        NSLog(@"jSON Data is : %@", jsonString);
        
        NSString *postLength = [NSString stringWithFormat:@"%lu", (unsigned long)[postData length]];
        
        NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:url];
        [request setHTTPMethod:@"POST"];
        [request setValue:postLength forHTTPHeaderField:@"Content-Length"];
        [request setValue:@"application/json" forHTTPHeaderField:@"Accept"];
        [request setValue:@"application/json" forHTTPHeaderField:@"Content-Type"];
        [request setHTTPBody:postData];
        
        NSLog(@"Request is : %@", request);
        
        NSError *error = [[NSError alloc] init];
        
        NSHTTPURLResponse *response = nil;
        
        NSData *urlData=[NSURLConnection sendSynchronousRequest:request returningResponse:&response error:&error];
        
        
        NSLog(@"Response Code : %ld", (long)[response statusCode]);
        
        if ([response statusCode] >= 200 && [response statusCode] < 300)
        {
            NSError *error = nil;
            NSDictionary *jsonData = [NSJSONSerialization
                                      JSONObjectWithData:urlData
                                      options:NSJSONReadingMutableContainers
                                      error:&error];
            NSLog(@"Response is : %@", jsonData);
            
            NSString *success = jsonData[@"success"];
            if([success isEqualToString:@"YES"])
            {
                [self alertStatus:@"Fine Applied":@"" :0];
                [self dismissViewControllerAnimated:YES completion:nil];
            }
            else{
                [self alertStatus:@"Error!":@"Could not add fine" :0];
            }
        }
        else {
            
            [self alertStatus:@"Connection Failed" :@"Connection Failed!" :0];
        }

        
        
    }
}

- (void) alertStatus:(NSString *)msg :(NSString *)title :(int) tag
{
    UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:title
                                                        message:msg
                                                       delegate:self
                                              cancelButtonTitle:@"Ok"
                                              otherButtonTitles:nil, nil];
    alertView.tag = tag;
    [alertView show];
}

- (IBAction)back:(id)sender {
    [self dismissViewControllerAnimated:YES completion:nil];
}
@end
