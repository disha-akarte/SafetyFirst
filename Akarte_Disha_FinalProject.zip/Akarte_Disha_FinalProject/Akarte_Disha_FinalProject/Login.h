//
//  Login.h
//  Akarte_Disha_FinalProject
//
//  Created by Disha Akarte on 4/1/17.
//  Copyright © 2017 Disha Akarte. All rights reserved.
//

#ifndef Login_h
#define Login_h

#import <Foundation/Foundation.h>
#import "Student.h"
#import "Vehicle.h"

@class Student, Vehicle;

@interface Login : NSObject

@property (nonatomic) NSInteger loginid;
@property (strong, nonatomic) NSString *username;
@property (strong, nonatomic) NSString *password;
@property (strong, nonatomic) NSString *role;
@property (strong,nonatomic) Student* student;

@property (strong,nonatomic) Vehicle* vehicle;

@end

#endif /* Login_h */
