//
//  VehicleRegistrationController.m
//  Akarte_Disha_FinalProject
//
//  Created by Disha Akarte on 4/10/17.
//  Copyright © 2017 Disha Akarte. All rights reserved.
//

#import "VehicleRegistrationController.h"
#import "ViewController.h"
#import "Login.h"
#import "Vehicle.h"
#import "SignUpOptionViewController.h"

@interface VehicleRegistrationController ()

@end

@implementation VehicleRegistrationController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
    if ([segue.identifier isEqualToString:@"cancelVehicleRegistration"]) {
        ViewController *vc = segue.destinationViewController;
    }
    else if([segue.identifier isEqualToString:@"BackToOptions"]){
        SignUpOptionViewController *svc = segue.destinationViewController;
    }
}

- (IBAction)BackToOptions:(id)sender {
    [self performSegueWithIdentifier:@"BackToOptions" sender:self];
}

- (IBAction)SaveVehicleDetails:(id)sender {

    
    if([self.vehicleUsername.text isEqual:@""]||[self.vehiclePassword.text isEqual:@""]||[self.vehicleCapacity.text isEqual:@""]||[self.vehivcleNumber.text isEqual:@""]||[self.adminAccessCode.text isEqual:@""]){
        [self alertStatus:@"Invalid input":@"Please fill out all the details properly" :0];
    }
    else{
        Login* login= [[Login alloc]init];
        login.username=self.vehicleUsername.text;
        login.password=self.vehiclePassword.text;
        login.role=@"Vehicle";
        
        Vehicle *vehicle = [[Vehicle alloc]init];
        vehicle.vehicleNumber = self.vehivcleNumber.text;
        vehicle.vehicleCapacity = self.vehicleCapacity.text;
        
        NSString* Url = @"http://localhost:8080/safetyfirst/addVehicle";
        NSURL *url = [NSURL URLWithString:Url];
        
        NSDictionary *vehicleInfo = [NSDictionary dictionaryWithObjectsAndKeys:
                                     [NSNumber numberWithInt:1],@"loginid",
                                     [self.vehicleCapacity text],@"capacity",
                                     [self.vehivcleNumber text],@"vehicleNumber",
                                     [self.vehiclePassword text],@"password",
                                     [self.vehicleUsername text],@"username",
                                     nil];
        
        NSLog(@"Vehicle Info is : %@", vehicleInfo);
        
        NSData *postData = [NSJSONSerialization dataWithJSONObject:vehicleInfo options:NSJSONWritingPrettyPrinted error:nil];
        
        
        NSString *jsonString = [[NSString alloc] initWithData:postData encoding:NSUTF8StringEncoding];
        NSLog(@"jSON Data is : %@", jsonString);
        
        NSString *postLength = [NSString stringWithFormat:@"%lu", (unsigned long)[postData length]];
        
        NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:url];
        [request setHTTPMethod:@"POST"];
        [request setValue:postLength forHTTPHeaderField:@"Content-Length"];
        [request setValue:@"application/json" forHTTPHeaderField:@"Accept"];
        [request setValue:@"application/json" forHTTPHeaderField:@"Content-Type"];
        [request setHTTPBody:postData];
        
        NSLog(@"Request is : %@", request);
        
        NSError *error = [[NSError alloc] init];
        
        NSHTTPURLResponse *response = nil;
        
        NSData *urlData=[NSURLConnection sendSynchronousRequest:request returningResponse:&response error:&error];
        
        
        NSLog(@"Response Code : %ld", (long)[response statusCode]);
        
        if ([response statusCode] >= 200 && [response statusCode] < 300)
        {
            NSError *error = nil;
            NSDictionary *jsonData = [NSJSONSerialization
                                      JSONObjectWithData:urlData
                                      options:NSJSONReadingMutableContainers
                                      error:&error];
            NSLog(@"Response is : %@", jsonData);
            
            NSInteger success = [jsonData[@"loginid"] integerValue];
            if(success >= 1)
            {
                [self alertStatus:@"Saved Successfully":@"" :0];
                [self dismissViewControllerAnimated:YES completion:nil];
            }
            else{
                [self alertStatus:@"Save error!":@"Could not save vehicle" :0];
            }
        }
        else {
            
            [self alertStatus:@"Connection Failed" :@"Connection Failed!" :0];
        }

    }
    
}

- (void) alertStatus:(NSString *)msg :(NSString *)title :(int) tag
{
    UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:title
                                                        message:msg
                                                       delegate:self
                                              cancelButtonTitle:@"Ok"
                                              otherButtonTitles:nil, nil];
    alertView.tag = tag;
    [alertView show];
}

@end
