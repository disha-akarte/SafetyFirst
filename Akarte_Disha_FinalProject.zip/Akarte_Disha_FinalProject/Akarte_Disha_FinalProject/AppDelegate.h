//
//  AppDelegate.h
//  Akarte_Disha_FinalProject
//
//  Created by Disha Akarte on 4/1/17.
//  Copyright © 2017 Disha Akarte. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "BookCabViewController.h"
#import "BookingsListTableViewController.h"

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@property BookCabViewController *bcvc;
@property BookingsListTableViewController *bltvc;


@end

