//
//  StudentRegistrationController.h
//  Akarte_Disha_FinalProject
//
//  Created by Disha Akarte on 4/10/17.
//  Copyright © 2017 Disha Akarte. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface StudentRegistrationController : UIViewController<UIImagePickerControllerDelegate,UINavigationControllerDelegate, UITextFieldDelegate>

@property (weak, nonatomic) IBOutlet UITextField *firstName;
@property (weak, nonatomic) IBOutlet UITextField *lastName;
@property (weak, nonatomic) IBOutlet UITextField *NUID;
@property (weak, nonatomic) IBOutlet UITextField *phone;
@property (weak, nonatomic) IBOutlet UITextField *username;
@property (weak, nonatomic) IBOutlet UITextField *password;

- (IBAction)saveStudent:(id)sender;

//- (IBAction)submitStudentdetails:(id)sender;
- (IBAction)browseImages:(id)sender;
- (IBAction)goBack:(id)sender;

@property (weak, nonatomic) IBOutlet UIImageView *StudentPhotoView;
@property (nonatomic) UIImagePickerController *imagePickerController;

@end
