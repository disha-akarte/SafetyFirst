package com.smatphones.safetyfirst.DAO;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.junit.Test;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.smatphones.safetyfirst.POJO.Login;


import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.springframework.stereotype.Repository;

import com.smatphones.safetyfirst.exception.AdException;

@Repository
public class LoginDAO extends DAO {
    
    public String auth(String username, String password) throws AdException{
    	  
        try {
            begin();
            Query q = getSession().createQuery("from Login where username = :username AND password = :password");
            q.setString("username", username);
            q.setString("password", password);
            Login useraccount = (Login) q.uniqueResult();
            commit();
            if(useraccount!=null){
            	return useraccount.role;
            }
            else{
            	return null;
            }
        } catch (HibernateException e) {
            rollback();
            throw new AdException("Could not get user " + username + password, e);
        }finally{
			if(getSession() != null){
				close();
			}
		}
    }

}

