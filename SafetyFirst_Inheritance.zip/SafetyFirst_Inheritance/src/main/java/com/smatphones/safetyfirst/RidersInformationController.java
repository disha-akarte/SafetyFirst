package com.smatphones.safetyfirst;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.smatphones.safetyfirst.DAO.ScheduleDAO;
import com.smatphones.safetyfirst.DAO.StudentDAO;
import com.smatphones.safetyfirst.DAO.VehicleDAO;
import com.smatphones.safetyfirst.POJO.Login;
import com.smatphones.safetyfirst.POJO.Schedule;
import com.smatphones.safetyfirst.POJO.Student;
import com.smatphones.safetyfirst.POJO.Vehicle;
import com.smatphones.safetyfirst.exception.AdException;

@Controller
public class RidersInformationController {


	@Autowired
	StudentDAO studentdao;
	
	@RequestMapping(value="/addFine",method=RequestMethod.POST)
	@ResponseBody
	public String GetRidersList(@RequestBody Student s) throws JsonParseException, JsonMappingException, IOException, AdException{

		System.out.println("In Apply Fine method of controller");
		
		JsonDataToString jsonObj= new JsonDataToString();
		String jsonToString="";
		
		try {
			int result = studentdao.addFine(s);
			if(result>0){
				jsonToString = jsonObj.successJSON("YES");
			}
			else{
				jsonToString = jsonObj.successJSON("NO");
			}
			System.out.println("Get Schedule method : \n"+jsonToString);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return jsonToString;
		

	}
	
}
