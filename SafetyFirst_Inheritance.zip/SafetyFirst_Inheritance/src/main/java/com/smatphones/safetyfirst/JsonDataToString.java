package com.smatphones.safetyfirst;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;

import com.smatphones.safetyfirst.POJO.Admin;
import com.smatphones.safetyfirst.POJO.Login;
import com.smatphones.safetyfirst.POJO.Schedule;
import com.smatphones.safetyfirst.POJO.Student;
import com.smatphones.safetyfirst.POJO.Vehicle;

public class JsonDataToString {
	
	public String convertStudentDataToJSON(Student student){
		JSONObject log = new JSONObject();
		JSONObject studentJSON = new JSONObject();
	
		studentJSON.put("firstname", student.getFirstname());
		studentJSON.put("lastname", student.getLastname());
		studentJSON.put("phone", student.getPhone());
		studentJSON.put("nuid", student.getNuid());

		studentJSON.put("loginid", student.getLoginid());
		studentJSON.put("username", student.getUsername());
		studentJSON.put("password", student.getPassword());
		studentJSON.put("role", student.getRole());
		studentJSON.put("fine", student.getFine());
		
		JSONArray bookings= new JSONArray();
		if(student.getBookings()!=null){
			for (Schedule schedule : student.getBookings()) {
				JSONObject sch= new JSONObject();
				
				sch.put("scheduleID",schedule.getScheduleID());
				sch.put("departureDate", schedule.getDepartureDate());
				sch.put("departureTime", schedule.getDepartureTime());
				sch.put("vehicleNumber", schedule.getVehicle().getVehicleNumber());		
				bookings.add(sch);			
			}	
			studentJSON.put("bookings", bookings);
		}
		String jsonBody = studentJSON.toString();
		return jsonBody;
	}
	
	public String convertVehicleDataToJSON(Vehicle vehicle){
		JSONObject log = new JSONObject();
		JSONObject vehicleJSON = new JSONObject();
	
		vehicleJSON.put("vehicleNumber", vehicle.getVehicleNumber());
		vehicleJSON.put("capacity", vehicle.getCapacity());
		vehicleJSON.put("loginid", vehicle.getLoginid());
		vehicleJSON.put("username", vehicle.getUsername());
		vehicleJSON.put("password", vehicle.getPassword());
		vehicleJSON.put("role", vehicle.getRole());

		String jsonBody = vehicleJSON.toString();
		return jsonBody;
	}
	
	public String convertAdminDataToJSON(Admin admin,List<Vehicle> vehicleList){
		JSONObject log = new JSONObject();
		JSONObject adminJSON = new JSONObject();
		
		JSONArray vehicleJSONList= new JSONArray();
		for (Vehicle vehicle : vehicleList) {
			JSONObject v= new JSONObject();
			v.put("vehicleNumber", vehicle.getVehicleNumber());
			v.put("capacity", vehicle.getCapacity());
			vehicleJSONList.add(v);			
		}
		
		adminJSON.put("loginid", admin.getLoginid());
		adminJSON.put("username", admin.getUsername());
		adminJSON.put("password", admin.getPassword());
		adminJSON.put("role", admin.getRole());
		adminJSON.put("accesscode", admin.getAccesscode());
		adminJSON.put("vehicleList", vehicleJSONList);

		String jsonBody = adminJSON.toString();
		return jsonBody;
	}
	
	public String convertScheduleToJSON(Schedule sch){
		JSONObject log = new JSONObject();
		JSONObject scheduleJSON = new JSONObject();		
		
		scheduleJSON.put("scheduleID", sch.getScheduleID());
		scheduleJSON.put("departureDate", sch.getDepartureDate());
		scheduleJSON.put("departureTime", sch.getDepartureTime());
		
		JSONObject v= new JSONObject();
		v.put("vehicleNumber", sch.getVehicle().getVehicleNumber());
		v.put("capacity", sch.getVehicle().getCapacity());
			
		JSONArray riders= new JSONArray();
		if(sch.getRiders()!=null){
		for (Student student : sch.getRiders()) {
			JSONObject stu= new JSONObject();
			
			stu.put("studentid", student.getLoginid());
			stu.put("firstname", student.getFirstname());
			stu.put("lastname", student.getLastname());
			stu.put("phone", student.getPhone());
			stu.put("nuid", student.getNuid());
			stu.put("fine", student.getFine());
			riders.add(stu);			
		}
			scheduleJSON.put("riders", riders);
		}
		scheduleJSON.put("vehicle", v);

		String jsonBody = scheduleJSON.toString();
		return jsonBody;
	}
	
	public String convertScheduleListDataToJSON(List<Schedule> scheduleList){
		
		JSONArray scheduleJSONList= new JSONArray();
		for (Schedule schedule : scheduleList) {
			JSONObject s= new JSONObject();
			s.put("scheduleID", schedule.getScheduleID());
			s.put("departureDate", schedule.getDepartureDate());
			s.put("departureTime", schedule.getDepartureTime());
			s.put("vehicleNumber", schedule.getVehicle().getVehicleNumber());
			s.put("loginid", schedule.getVehicle().getLoginid());
			s.put("capacity", schedule.getVehicle().getCapacity());
			
			if(schedule.getRiders()!=null){
			JSONArray riders= new JSONArray();
			for (Student student : schedule.getRiders()) {
				JSONObject stu= new JSONObject();
				
				stu.put("studentid", student.getLoginid());
				stu.put("firstname", student.getFirstname());
				stu.put("lastname", student.getLastname());
				stu.put("phone", student.getPhone());
				stu.put("nuid", student.getNuid());
				stu.put("fine", student.getFine());
				riders.add(stu);			
			}

			s.put("riders", riders);
			}
			
			scheduleJSONList.add(s);			
		}
	
		String jsonBody = scheduleJSONList.toString();
		return jsonBody;
	}
	
	
	public String successJSON(String val){
		
		JSONObject successJSON = new JSONObject();
	
		successJSON.put("success", val);
		
		String jsonBody = successJSON.toString();
		return jsonBody;
	}
	
}

