package com.smatphones.safetyfirst.DAO;

import org.hibernate.HibernateException;
import org.hibernate.Query;

import com.smatphones.safetyfirst.POJO.Admin;
import com.smatphones.safetyfirst.POJO.Student;
import com.smatphones.safetyfirst.POJO.Vehicle;
import com.smatphones.safetyfirst.exception.AdException;

public class AdminDAO extends DAO {
	
	 public Admin authAccessCode(String uname)throws AdException{

	    	try {
			
	    	begin();    
	    	Query q = getSession().createQuery("from Admin where username = :id");
	    	q.setString("id", uname);
	    	
	    	Admin admin = (Admin) q.uniqueResult();
	    	commit();
	    	if(admin!=null){
		    	System.out.println("admin returned has number : "+admin.getAccesscode());
		    	return admin;
	    	}
	    	else{
	    		System.out.println("No match found ");
	    		return null;
	    	}
	    	
	    	}
	    	catch (HibernateException e) {
	            rollback();
	            throw new AdException("Exception while finding admin: " + e.getMessage());
	        }
	    	finally{
				if(getSession() != null){
					close();
				}
			}
	    }
	    
}
