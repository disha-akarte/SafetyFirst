package com.smatphones.safetyfirst.DAO;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Query;

import com.smatphones.safetyfirst.POJO.Student;
import com.smatphones.safetyfirst.POJO.Vehicle;
import com.smatphones.safetyfirst.exception.AdException;

public class VehicleDAO extends DAO {
	 public Vehicle insert(String username,String password,String vehicleNumber,String vehicleCapacity)
		throws AdException {
			try {
				System.out.println("Inside student dao insert method");
				begin();       
				Vehicle vehicle = new Vehicle(username, password, vehicleNumber, vehicleCapacity);
				getSession().save(vehicle);
				commit();
				System.out.println("Student added in dao : "+vehicle.getVehicleNumber());
				return vehicle;
			} catch (HibernateException e) {
				rollback();
				throw new AdException("Exception while creating vehicle: " + e.getMessage());
			}
			finally{
				if(getSession() != null){
					close();
				}
			}
		}
	 
	 public Vehicle findVehicle(String uname)throws AdException{

	    	try {
			
	    	begin();    
	    	Query q = getSession().createQuery("from Login where username = :id");
	    	q.setString("id", uname);
	    	
	    	Vehicle vehicle = (Vehicle) q.uniqueResult();
	    	commit();
	    	if(vehicle!=null){
		    	System.out.println("vehicle returned has number : "+vehicle.getVehicleNumber());
		    	return vehicle;
	    	}
	    	else{
	    		System.out.println("Vehicle is null ");
	    		return null;
	    	}
	    	
	    	}
	    	catch (HibernateException e) {
	            rollback();
	            throw new AdException("Exception while finding vehicle: " + e.getMessage());
	        }
	    	finally{
				if(getSession() != null){
					close();
				}
			}
	    }
	 
	 public ArrayList<Vehicle> FetchVehicleList() throws AdException {
			
			try {
	            begin();   
	            ArrayList<Vehicle> vehicleList = new ArrayList<Vehicle>();
		    	Query q = getSession().createQuery("from Vehicle");
		    	List list = q.list();
		    		    	
		    	Iterator<Vehicle> jobIterator = list.iterator();
		
		    	while (jobIterator.hasNext())
	            {            		
		    		Vehicle a = (Vehicle) jobIterator.next();
		    		System.out.println("Vehicle added : "+a.getVehicleNumber());
		    		vehicleList.add(a);                        
	            }
	            commit();
	            return vehicleList;
	        } catch (HibernateException e) {
	            rollback();
	            throw new AdException("Could not retirieve list of vehicles :" +e.getMessage());
	        }
			finally{
				if(getSession() != null){
					close();
				}
			}
			
		}
	    
}
