package com.smatphones.safetyfirst;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.fasterxml.jackson.annotation.JsonSubTypes.Type;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.smatphones.safetyfirst.DAO.ScheduleDAO;
import com.smatphones.safetyfirst.DAO.StudentDAO;
import com.smatphones.safetyfirst.POJO.Schedule;
import com.smatphones.safetyfirst.POJO.Student;
import com.smatphones.safetyfirst.POJO.Vehicle;
import com.smatphones.safetyfirst.exception.AdException;

@Controller
public class AddScheduleController {
	
	@Autowired
	ScheduleDAO scheduledao;
	StudentDAO studentdao;
	
	@RequestMapping(value="/addSchedule",method=RequestMethod.POST,consumes = "application/json")
	@ResponseBody
	public String AddSchedule(@RequestBody Schedule s) throws JsonParseException, JsonMappingException, IOException, AdException{
		JsonDataToString jsonObj= new JsonDataToString();
		String jsonToString="";
		System.out.println("In Schedule adding controller");
		Schedule schedule = new Schedule();
		try {
	
			String departureDate = s.getDepartureDate();
			String departureTime = s.getDepartureTime();
			Vehicle vehicle = s.getVehicle();
			
			schedule = (Schedule)scheduledao.insert(vehicle,departureDate,departureTime);
			jsonToString= jsonObj.convertScheduleToJSON(schedule);
		
		} catch (Exception e) {
			e.printStackTrace();
		}
		if(schedule!=null){
			System.out.println("Schedule added with departure date :"+schedule.getDepartureDate()+" and departure time : "+schedule.getDepartureTime());
			return jsonToString;
		}
		else{
			return null;
		}
	}
	
	@RequestMapping(value="/getSchedule",method=RequestMethod.GET)
	@ResponseBody
	public String GetSchedule() throws JsonParseException, JsonMappingException, IOException, AdException{

		System.out.println("In get Schedule adding controller");
		List scheduleList = new ArrayList<Schedule>();
		JsonDataToString jsonObj= new JsonDataToString();
		String jsonToString="";
		
		try {
	
			ScheduleDAO scheduledao = new ScheduleDAO();
			scheduleList = scheduledao.FetchScheduleList();
			jsonToString= jsonObj.convertScheduleListDataToJSON(scheduleList);
			System.out.println("Get Schedule method : \n"+jsonToString);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return jsonToString;
		

	}
	
	@RequestMapping(value="/addRider",method=RequestMethod.POST)
	@ResponseBody
	public String AddRider(@RequestBody Map<String, Map<String, String>> s) throws JsonParseException, JsonMappingException, IOException, AdException{

			Map<String, String> scheduleMap = s.get("schedule");
			Map<String, String> studentMap = s.get("student");	
			
		String scheduleID =String.valueOf(scheduleMap.get("scheduleID"));
			
		String nuid = studentMap.get("nuid");
	
		Schedule sch = new Schedule();
		Student stu = new Student();
		
		System.out.println("In add rider method of controller");
		List riderList = new ArrayList<Schedule>();
		JsonDataToString jsonObj= new JsonDataToString();
		String jsonToString="";
		
		try {
			StudentDAO studentdao = new StudentDAO();
			
			stu = studentdao.findStudentByNuid(nuid);
			
			ScheduleDAO scheduledao = new ScheduleDAO();
		
			sch = scheduledao.GetScheduleFromScheduleID(scheduleID);
			sch = scheduledao.addRider(sch, stu);
			
			if(sch!=null){
				studentdao.addBooking(stu, sch);
			}
			jsonToString= jsonObj.convertStudentDataToJSON(stu);
			
			
			
		} catch (Exception e) {	
			e.printStackTrace();
		}
		
		return jsonToString;
	}
		

}
