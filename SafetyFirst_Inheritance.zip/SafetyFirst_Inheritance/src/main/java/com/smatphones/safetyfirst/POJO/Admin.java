package com.smatphones.safetyfirst.POJO;

import java.util.HashSet;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.Table;

@Entity
@Table(name="Admin")
@PrimaryKeyJoinColumn(name="loginid")
public class Admin extends Login {
	
	@Column(name = "accesscode")
	private String accesscode;

	public String getAccesscode() {
		return accesscode;
	}

	public void setAccesscode(String accesscode) {
		this.accesscode = accesscode;
	}
	
	public Admin(){
		
	}
	
	public Admin(String username, String password, String accesscode){
		this.setUsername(username);
		this.setPassword(password);
		this.setAccesscode(accesscode);
		super.setRole("Admin");
	}
	

}
