package com.smatphones.safetyfirst;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.smatphones.safetyfirst.DAO.ScheduleDAO;
import com.smatphones.safetyfirst.DAO.StudentDAO;
import com.smatphones.safetyfirst.POJO.Schedule;
import com.smatphones.safetyfirst.POJO.Student;
import com.smatphones.safetyfirst.exception.AdException;

@Controller
public class StudentBookingsController {
	
	
	@Autowired
	StudentDAO studentdao;
	
	@RequestMapping(value="/getStudentBookings",method=RequestMethod.POST)
	@ResponseBody
	public String GetBookings(@RequestBody Student student) throws JsonParseException, JsonMappingException, IOException, AdException{

		System.out.println("In get Scheget bookings controller");

		Student fetchedStudent = studentdao.findStudentByNuid(student.getNuid());
		JsonDataToString jsonObj= new JsonDataToString();
		String jsonToString="";
		
		try {
	
			
			jsonToString= jsonObj.convertStudentDataToJSON(fetchedStudent);
			System.out.println("Get Student Bookings method : \n" +jsonToString);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return jsonToString;
		

	}
	
	@RequestMapping(value="/deleteRider",method=RequestMethod.POST)
	@ResponseBody
	public String DeleteBooking(@RequestBody Map<String, Map<String, String>> s) throws JsonParseException, JsonMappingException, IOException, AdException{

		Map<String, String> scheduleMap = s.get("schedule");
		Map<String, String> studentMap = s.get("student");
		
		String scheduleID =String.valueOf(scheduleMap.get("scheduleID"));
		
		String nuid = studentMap.get("nuid");
	
		Schedule sch = new Schedule();
		Student stu = new Student();
		System.out.println("In delete booking method of controller");
		
		JsonDataToString jsonObj= new JsonDataToString();
		String jsonToString="";
		
		try {
			StudentDAO studentdao = new StudentDAO();
			
			stu = studentdao.findStudentByNuid(nuid);
			
			ScheduleDAO scheduledao = new ScheduleDAO();
		
			sch = scheduledao.GetScheduleFromScheduleID(scheduleID);
			
			sch = scheduledao.removeRider(sch, stu);
			
			if(sch!=null){
				System.out.println("Removing booking for : "+sch);
				studentdao.removeBooking(stu, sch);
			}
			
			System.out.println("In Student Bookings Controller Total Trips : "+ stu.getBookings().size());
			System.out.println("In Student Bookings Contrller Total Riders : "+ sch.getRiders().size());
			jsonToString= jsonObj.convertStudentDataToJSON(stu);
			
			
			
		} catch (Exception e) {	
			e.printStackTrace();
		}
		
		return jsonToString;

	}

}
