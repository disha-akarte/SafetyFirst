package com.smatphones.safetyfirst.DAO;

import com.smatphones.safetyfirst.POJO.Login;
import com.smatphones.safetyfirst.POJO.Schedule;
import com.smatphones.safetyfirst.POJO.Student;


import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.springframework.stereotype.Repository;

import com.smatphones.safetyfirst.exception.AdException;

@Repository
public class StudentDAO extends DAO {
    
    public Student insert(String username,String password,String firstname,String lastname,	
			String phone,String nuid)
	throws AdException {
		try {
			System.out.println("Inside student dao insert method");
			begin();       
			Student student = new Student(username, password, firstname, lastname, nuid, phone);
			getSession().save(student);
			commit();
			System.out.println("Student added in dao : "+student.getFirstname());
			return student;
		} catch (HibernateException e) {
			rollback();
			throw new AdException("Exception while creating user: " + e.getMessage());
		}
		finally{
			if(getSession() != null){
				close();
			}
		}
	}
    
    public Student findStudent(String uname)throws AdException{

    	try {
		
    	begin();    
    	Query q = getSession().createQuery("from Login where username = :id");
    	q.setString("id", uname);    	
    	Student student = (Student) q.uniqueResult();
    	commit();
    	if(student!=null){
	    	System.out.println("Student returned has first name : "+student.firstname);
	    	return student;
    	}
    	else{
    		System.out.println("Student is null ");
    		return null;
    	}
    	
    	}
    	catch (HibernateException e) {
            rollback();
            throw new AdException("Exception while creating user: " + e.getMessage());
        }
    	finally{
			if(getSession() != null){
				close();
			}
		}
    }
    
    public Student findStudentByNuid(String nuid)throws AdException{

    	try {
		
    	begin();    
    	Query q = getSession().createQuery("from Login where nuid = :id");
    	q.setString("id", nuid);
    	
    	Student student = (Student) q.uniqueResult();
    	commit();
    	if(student!=null){
	    	System.out.println("Student returned has first name : "+student.firstname);
	    	return student;
    	}
    	else{
    		System.out.println("Student is null ");
    		return null;
    	}
    	
    	}
    	catch (HibernateException e) {
            rollback();
            throw new AdException("Exception while creating user: " + e.getMessage());
        }
    	finally{
			if(getSession() != null){
				close();
			}
		}
    }
    
    public void addBooking(Student stu, Schedule s)throws AdException{
 
    	try {
		getSession();
    	begin();   
    	
    	if(stu!=null){
	    	System.out.println("Student returned has first name : "+stu.firstname);
	    	stu.getBookings().add(s);
	    	getSession().update(stu);
	    	System.out.println("Trips booked : "+ stu.getBookings().size());
            System.out.println("Schedule added : "+s.getDepartureTime());
	     	commit();
    	}
    	else{
    		System.out.println("Student is null ");	
    	}
    	
    	}
    	catch (HibernateException e) {
            rollback();
            throw new AdException("Exception while creating user: " + e.getMessage());
        }
    	finally{
			if(getSession() != null){
				close();
			}
		}
    }
    
    public int addFine(Student stu)throws AdException{
    	  
    	
    	try {
    		getSession();
    		begin();    
    	if(stu!=null){
	    	
    		Query query = getSession().createQuery("update Student set fine = :fine" +
    				" where nuid = :nuid");
    		query.setString("fine", stu.getFine());
    		query.setString("nuid", stu.getNuid());
			int result = query.executeUpdate();
	     	commit();
	     	return result;
    	}
    	else{
    		System.out.println("Student is null ");	
    		return 0;
    	}
    	}
    	catch (HibernateException e) {
            rollback();
            throw new AdException("Exception while addding fine for user: " + e.getMessage());
        }
    	finally{
			if(getSession() != null){
				close();
			}
		}	
    }
    
    public void removeBooking(Student stu, Schedule s)throws AdException{

    	   	
    	try {
    		getSession();
    		begin(); 
    	if(stu!=null){
	    	System.out.println("Student in Remove booking has first name : "+stu.firstname);
	    	System.out.println("Total Trips before remove: "+ stu.getBookings().size());
	    	stu.getBookings().remove(s);
	    	getSession().update(stu);
	    	System.out.println("Total Trips after remove: "+ stu.getBookings().size());
            System.out.println("Schedule removed : "+s.getDepartureTime());
            commit();
    	}
    	else{
    		System.out.println("Student is null ");	
    	}
    	
    	}
    	catch (HibernateException e) {
            rollback();
            throw new AdException("Exception while creating user: " + e.getMessage());
        }
    	finally{
			if(getSession() != null){
				getSession().close();
			}
		}	
    }
    
    
    
    
    
	
}

