package com.smatphones.safetyfirst;

import java.io.*;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.smatphones.safetyfirst.DAO.StudentDAO;
import com.smatphones.safetyfirst.DAO.VehicleDAO;
import com.smatphones.safetyfirst.POJO.Student;
import com.smatphones.safetyfirst.POJO.Vehicle;
import com.smatphones.safetyfirst.exception.AdException;


@Controller
public class VehicleRegistrationController {

	@Autowired
	VehicleDAO vehicledao;
	
	@RequestMapping(value="/addVehicle",method=RequestMethod.POST,consumes = "application/json")
	@ResponseBody
	public Vehicle AddVehicle(@RequestBody Vehicle v) throws JsonParseException, JsonMappingException, IOException, AdException{

		System.out.println("In Vehicle Registration controller");
		Vehicle vehicle = new Vehicle();
		try {
	
			String username = v.getUsername();
			String password = v.getPassword();
			String vehName = v.getVehicleNumber();
			String vehCap = v.getCapacity();
			
		
		System.out.println("Username Retrieved : " + username);
		
		vehicle = (Vehicle)vehicledao.insert(username,password,vehName,vehCap);
		System.out.println("vehicle added is  : " + vehicle.getVehicleNumber());
		
		} catch (Exception e) {
			e.printStackTrace();
		}
		if(vehicle!=null){
			System.out.println("Capacity of added vehicle is  : " + vehicle.getCapacity());
			return vehicle;
		}
		else{
			return null;
		}
		

	}
		

}
