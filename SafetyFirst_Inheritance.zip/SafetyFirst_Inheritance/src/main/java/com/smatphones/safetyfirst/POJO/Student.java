package com.smatphones.safetyfirst.POJO;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.ManyToMany;
import javax.persistence.OneToMany;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;


@Entity
@Table(name="student")
@PrimaryKeyJoinColumn(name="loginid")
public class Student extends Login implements Serializable{

	public Student(String username, String password,String firstName, String lastName,
			String nuid,String phone) {
			this.setUsername(username);
			this.setPassword(password);
			this.setFirstname(firstName);
			this.setLastname(lastName);
			this.setNuid(nuid);
			this.setPhone(phone);
			super.setRole("Student");
			this.setFine("0");
	}

	public Student() {
		this.bookings = new HashSet<Schedule>();
	}
	
	@Column(name="firstname")
	public String firstname;
	
	@Column(name="lastname")
	private String lastname;
	
	@ManyToMany(fetch = FetchType.EAGER, mappedBy = "riders", cascade = CascadeType.ALL)
	private Set<Schedule> bookings;
	
	public Set<Schedule> getBookings() {
		return bookings;
	}

	public void setBookings(Set<Schedule> bookings) {
		this.bookings = bookings;
	}

	@Column(name="nuid")
	private String nuid;
	
	@Column(name="phone")
	private String phone;
	
	@Column(name="fine")
	private String fine;
	
	public String getFirstname() {
		return firstname;
	}
	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}
	public String getLastname() {
		return lastname;
	}
	public void setLastname(String lastname) {
		this.lastname = lastname;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public String getNuid() {
		return nuid;
	}
	public void setNuid(String nuid) {
		this.nuid = nuid;
	}

	public String getFine() {
		return fine;
	}

	public void setFine(String fine) {
		this.fine = fine;
	}

}
