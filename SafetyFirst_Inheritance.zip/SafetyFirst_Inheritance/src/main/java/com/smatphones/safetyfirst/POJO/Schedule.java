package com.smatphones.safetyfirst.POJO;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;


@Entity
public class Schedule {
	
	@Id
	@GeneratedValue
	@Column(name="scheduleid")
	int scheduleID;
	
	@ManyToOne
	@JoinColumn(name="vehicleID")
	private Vehicle vehicle;
	
	@Column(name="departureDate")
	public String departureDate;
	
	
	@ManyToMany(fetch = FetchType.EAGER, cascade = CascadeType.ALL)
	@JoinTable(name = "schedule_student", catalog = "safetyfirstSmartphones", joinColumns = {
			@JoinColumn(name = "scheduleid") },
			inverseJoinColumns = { @JoinColumn(name = "loginid") })
	@JsonIgnore
	private Set<Student> riders;
	
	@Column(name="departureTime")
	private String departureTime;
	
	public Schedule(){
		this.riders = new HashSet<Student>();
	}
	
	public Set<Student> getRiders() {
		return riders;
	}

	public void setRiders(Set<Student> riders) {
		this.riders = riders;
	}
	
	public Schedule(Vehicle vehicle,String departureDate,String departureTime){
		this.setDepartureDate(departureDate);
		this.setDepartureTime(departureTime); 
		this.setVehicle(vehicle);
	}

	public int getScheduleID() {
		return scheduleID;
	}

	public Vehicle getVehicle() {
		return vehicle;
	}

	public void setVehicle(Vehicle vehicle) {
		this.vehicle = vehicle;
	}

	public String getDepartureDate() {
		return departureDate;
	}

	public void setDepartureDate(String departureDate) {
		this.departureDate = departureDate;
	}

	public String getDepartureTime() {
		return departureTime;
	}

	public void setDepartureTime(String departureTime) {
		this.departureTime = departureTime;
	}
	
	

}
