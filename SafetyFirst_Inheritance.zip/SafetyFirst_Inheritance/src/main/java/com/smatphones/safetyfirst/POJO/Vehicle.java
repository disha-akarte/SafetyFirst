package com.smatphones.safetyfirst.POJO;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIdentityInfo;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.ObjectIdGenerators;

@Entity
@Table(name="vehicle")
@PrimaryKeyJoinColumn(name="loginid")
public class Vehicle extends Login implements Serializable {
	
	@Column(name = "vehicleNumber")
	private String vehicleNumber;
	
	@Column(name = "capacity")
	String capacity;
	
	public String getVehicleNumber() {
		return vehicleNumber;
	}
	public void setVehicleNumber(String vehicleNumber) {
		this.vehicleNumber = vehicleNumber;
	}
	public String getCapacity() {
		return capacity;
	}
	public void setCapacity(String capacity) {
		this.capacity = capacity;
	}
	
	@OneToMany(fetch = FetchType.EAGER, mappedBy="vehicle", cascade = CascadeType.ALL)
	@JsonIgnoreProperties(value = "vehicle")
	private Set<Schedule> trips;

	public Set<Schedule> getTrips() {
		return trips;
	}
	public void setTrips(Set<Schedule> trips) {
		this.trips = trips;
	}
	
	public Vehicle(){
		this.trips = new HashSet<Schedule>();
		
	}
	
	public Vehicle(String username, String password, String vehicleNumber, String vehicleCapacity){
		this.setUsername(username);
		this.setPassword(password);
		this.setVehicleNumber(vehicleNumber);
		this.setCapacity(vehicleCapacity);
		super.setRole("Vehicle");
	}
	

}
