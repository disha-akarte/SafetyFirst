package com.smatphones.safetyfirst;

import java.io.*;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.smatphones.safetyfirst.DAO.StudentDAO;
import com.smatphones.safetyfirst.POJO.Student;
import com.smatphones.safetyfirst.exception.AdException;


@Controller
public class StudentRegistrationController {

	@Autowired
	StudentDAO studentdao;
	
	@RequestMapping(value="/addStudent",method=RequestMethod.POST,consumes = "application/json")
	@ResponseBody
	public Student AddStudent(@RequestBody Student s) throws JsonParseException, JsonMappingException, IOException, AdException{

		System.out.println("In Student Registration controller");
		Student student = new Student();
		try {
	
			String username = s.getUsername();
			String password = s.getPassword();
			String fName = s.getFirstname();
			String lName = s.getLastname();
			String phone = s.getPhone();
			String nuid = s.getNuid(); 
		
		System.out.println("Username Retrieved : " + username);
		
		student = (Student)studentdao.insert(username,password,fName,lName,phone,nuid);
		System.out.println("student added is  : " + student.getFirstname());
		
		} catch (Exception e) {
			e.printStackTrace();
		}
		if(student!=null){
			System.out.println("student nuid added is  : " + student.getNuid());
			return student;
		}
		else{
			return null;
		}
		

	}
		

}
