package com.smatphones.safetyfirst.DAO;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import org.hibernate.HibernateException;
import org.hibernate.Query;

import com.smatphones.safetyfirst.POJO.Schedule;
import com.smatphones.safetyfirst.POJO.Student;
import com.smatphones.safetyfirst.POJO.Vehicle;
import com.smatphones.safetyfirst.exception.AdException;

public class ScheduleDAO extends DAO {
	
	public Schedule insert(Vehicle vehicle,String departureDate,String departureTime)
	throws AdException {
		try {
			System.out.println("Inside schedule dao insert method");
			begin();
			

        	Query q = getSession().createQuery("from Vehicle where vehicleNumber = :id");
        	q.setString("id",vehicle.getVehicleNumber());
        	Vehicle v = (Vehicle)q.uniqueResult();
		
			Schedule schedule = new Schedule(v,departureDate,departureTime);
			v.getTrips().add(schedule);
			getSession().update(v);
			getSession().save(schedule);
			commit();
			System.out.println("Schedule added in dao : "+schedule.getScheduleID());
			return schedule;
		} catch (HibernateException e) {
			rollback();
			throw new AdException("Exception while creating schedule: " + e.getMessage());
		}
		finally{
			if(getSession() != null){
				close();
			}
		}
	}
	
	public ArrayList<Schedule> FetchScheduleList() throws AdException {
		
		try {
            begin();   
            ArrayList<Schedule> scheduleList = new ArrayList<Schedule>();
	    	Query q = getSession().createQuery("from Schedule");
	    	List list = q.list();
	    		    	
	    	Iterator<Schedule> jobIterator = list.iterator();
	
	    	while (jobIterator.hasNext())
            {            		
	    		Schedule a = (Schedule) jobIterator.next();
	    		scheduleList.add(a);                        
            }
            commit();
            return scheduleList;
        } catch (HibernateException e) {
            rollback();
            throw new AdException("Could not retirieve list of vehicles :" +e.getMessage());
        }
		finally{
			if(getSession() != null){
				close();
			}
		}
		
	}
	
	public Schedule GetScheduleFromScheduleID(String schedueId) throws AdException {
			
			try {
	            begin();   
	            
		    	Query q = getSession().createQuery("from Schedule where scheduleID = :id");
		    	q.setString("id", schedueId);
		    	Schedule sch = (Schedule)q.uniqueResult();
		    	
	            commit();
	            return sch;
	        } catch (HibernateException e) {
	            rollback();
	            throw new AdException("Could not retirieve list of vehicles :" +e.getMessage());
	        }
			finally{
				if(getSession() != null){
					close();
				}
			}
			
		}
	
	public Schedule addRider(Schedule s, Student stu) throws AdException{
		try {
			
            begin();   
	    	s.getRiders().add(stu);
	    	getSession().update(s);
			commit();
			System.out.println("Riders added : "+stu.getFirstname());
            System.out.println("Riders count : "+s.getRiders().size());
			return s;
        } catch (HibernateException e) {
            rollback();
            throw new AdException("Could not retrieve list of vehicles :" +e.getMessage());
        }
		finally{
			if(getSession() != null){
				close();
			}
		}
	}
	
	public Schedule removeRider(Schedule s, Student stu) throws AdException{
		try {
			getSession();
            begin();   
            System.out.println("Riders before deletion : "+s.getRiders().size());
	    	s.getRiders().remove(stu);
	    	System.out.println("Riders after deletion : "+s.getRiders().size());
	    	getSession().update(s);
			commit();
			System.out.println("Rider removed : "+stu.getFirstname());
            System.out.println("Riders count : "+s.getRiders().size());
			return s;
        } catch (HibernateException e) {
            rollback();
            throw new AdException("Could not retrieve list of vehicles :" +e.getMessage());
        }
		finally{
			if(getSession() != null){
				close();
			}
		}
	}
	    
}
