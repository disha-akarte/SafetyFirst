package com.smatphones.safetyfirst;


import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.smatphones.safetyfirst.DAO.AdminDAO;
import com.smatphones.safetyfirst.DAO.LoginDAO;
import com.smatphones.safetyfirst.DAO.StudentDAO;
import com.smatphones.safetyfirst.DAO.VehicleDAO;
import com.smatphones.safetyfirst.POJO.Admin;
import com.smatphones.safetyfirst.POJO.Login;
import com.smatphones.safetyfirst.POJO.Student;
import com.smatphones.safetyfirst.POJO.Vehicle;
import com.smatphones.safetyfirst.exception.AdException;


@Controller
public class UserLoginController {

	@Autowired
	LoginDAO logindao;
	StudentDAO studentdao;
	VehicleDAO vehicledao;
	AdminDAO admindao;
	

	@RequestMapping(value="/loginStudent",method=RequestMethod.POST)
	@ResponseBody
	public Student LoginCheck(@RequestBody Login l) throws AdException{
		System.out.println("In Login controller");
		String username = l.getUsername();
		String password = l.getPassword();
		System.out.println("Username from objective c : " + username);
		String role = logindao.auth(username, password);
		Student student=null;
		
		if( role!=null){
			JsonDataToString jsonObj= new JsonDataToString();
			String jsonToString="";
			System.out.println("Login Role : "+role);
			if(role.equalsIgnoreCase("Student")){
				System.out.println("Login ID from objective c: "+l.getLoginid());
				StudentDAO studentdao = new StudentDAO();
				student = studentdao.findStudent(l.getUsername());	
				// = new Student("d", "d", "d", "d", "d", "d");
				if(student!=null){
					System.out.println("Student retrieved has userid : "+student.getUsername());
					jsonToString=jsonObj.convertStudentDataToJSON(student);
				}
				else{
					System.out.println("Student is null ");
				}
			}
			System.out.println(jsonToString);
			return student;
		} else{
			System.out.println("Login details not found!");
			return null;
		}
	}
	
	@RequestMapping(value="/login",method=RequestMethod.POST)
	@ResponseBody
	public String LoginAuth(@RequestBody Login l) throws AdException{
		System.out.println("In Login controller");
		String username = l.getUsername();
		String password = l.getPassword();
		System.out.println("Username from objective c : " + username);
		String role = logindao.auth(username, password);
		Student student=null;
		Vehicle vehicle=null;
		Admin admin= null;
		
		if( role!=null){
			JsonDataToString jsonObj= new JsonDataToString();
			String jsonToString="";
			System.out.println("Login Role : "+role);
			if(role.equalsIgnoreCase("Student")){
				System.out.println("Login ID from objective c: "+l.getLoginid());
				StudentDAO studentdao = new StudentDAO();
				student = studentdao.findStudent(l.getUsername());	
				if(student!=null){
					System.out.println("Student retrieved has userid : "+student.getUsername());
					jsonToString=jsonObj.convertStudentDataToJSON(student);
				}
				else{
					System.out.println("Student is null ");
				}
			}
			else if(role.equalsIgnoreCase("Vehicle")){
				System.out.println("Login ID from objective c: "+l.getLoginid());
				VehicleDAO vehicledao = new VehicleDAO();
				vehicle = vehicledao.findVehicle(l.getUsername());
				if(vehicle!=null){
					System.out.println("Vehicle retrieved has userid : "+vehicle.getVehicleNumber());
					jsonToString=jsonObj.convertVehicleDataToJSON(vehicle);
				}
				else{
					System.out.println("Vehicle is null ");
				}
			}
			else if(role.equalsIgnoreCase("Admin")){
				AdminDAO admindao = new AdminDAO();
				admin = admindao.authAccessCode(l.getUsername());
				if(admin!=null){
					System.out.println("Admin retrieved in userlogin controller has accesscode : "+admin.getAccesscode());
					 List vehicleList = new ArrayList<Vehicle>();
				      try {
						  VehicleDAO vehicledao = new VehicleDAO();
				    	  vehicleList = vehicledao.FetchVehicleList();  
				    	  jsonToString=jsonObj.convertAdminDataToJSON(admin,vehicleList);				    	  
			          } catch (Exception e) {
			            System.out.println(e.getMessage());
			          }	
				}
				else{
					System.out.println("Access code not verified ");
				}
			}
			System.out.println("JSON String is : "+jsonToString);
			return jsonToString;
		} else{
			System.out.println("Login details not found!");
			return null;
		}
	}
	



}
